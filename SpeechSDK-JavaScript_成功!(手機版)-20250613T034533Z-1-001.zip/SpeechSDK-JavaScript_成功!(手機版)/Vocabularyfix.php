<?php
session_start();  //很重要，可以用的變數存在session裡
/*$user_id = $_SESSION["id"];*/
$user_icon = $_SESSION["icon"];
$user_name = $_SESSION["name"];
/*$user_intro = $_SESSION["intro"];
$user_occu = $_SESSION["occu"];*/

mb_internal_encoding("UTF-8");

$phpVariable = $_GET['data'];
//連結資料庫
$link = new PDO("mysql:dbname=EnglishSpeakingTrainingApp;host=localhost","root","0000");

$stmt = $link->prepare("SELECT * FROM vocabularyFIX WHERE vtype = :vtype");

// 繫結參數
$stmt->bindParam(':vtype', $phpVariable, PDO::PARAM_STR);
   
// 執行查詢
$stmt->execute();
   
// 取得結果
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$i = 0;
foreach ($result as $row) {
    // 處理每一列的資料
    $arr_vocabulary_data[$i] = $row['vocabulary'];
    $arr_Example_sentences_data[$i] = $row['Example_sentences'];   
    ++$i;
}
?>

<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <title>Speaking practice</title>
    <link rel="stylesheet" type="text/css" href="header.css">
    <link rel="stylesheet" type="text/css"
        href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
    <link rel="stylesheet" type="text/css"
        href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-2-9/css/5-2-9.css">
    <link href="record2.css" rel="stylesheet">
    <script src="microsoft.cognitiveservices.speech.sdk.bundle.js"></script>
    <script src="final6.js">//final4正式</script>

</head>

<script>var a = 1;</script>
<style>
    footer {
        background-color: gainsboro;
        margin: 0px;
        padding: 1%;
        text-align: center;
    }
    /* 定義三欄佈局的容器 */
    .container {
        display: flex;
    }

        /* 中間分栏的樣式 */
    .middle-column {
        flex: 2;
        width: 20%;
        background-color: #E8E7E7;
        min-height: 600px;
        height:1500px;
    }

    /* 聊天室對話框的樣式 */
    .chat-box {
        margin-top: 60px;
        max-width: 100%;
        min-height: 300px;
        height: 1300px;
        overflow-y: auto;
        border: 1px solid #ccc;
        padding: 10px;
        background-color: #fff;
        border-radius: 20px;
        /* 設定圓角背景框 */
    }

    .Question-num{
        font-size:60px;
    }

    .chat-container {
        display: flex;
        flex-direction: column;
        position: relative;
        text-align: center;
        font-size: 25px;
    }


    hr {
        position: static;
    }
    
    .chat-box div button{
        background-color: lightblue;
        left:0%;
        width:100%;
        border: 5px;
        margin:10px;
        color: black;
        font-size: 40px;
        cursor: pointer;
        transition: filter 0.3s ease;
        border-radius: 5px;
    }

    .speech_logo {
        font-size: 50px;
        font-weight: bold;
        text-align:center;
        /*position: absolute;
        right:5%;*/

        /*color: orange;*/
    }

    nav li.has-child>div {
    position: absolute;
    z-index: 9999; /* 一个较高的数值，确保它位于其他元素上方 */
    border-radius: 5%;
    right: 0;
    top: 62px;
    background: white;
    width: 200px;
    visibility: hidden;
    opacity: 0;
    transition: all .3s;
}

.practicevocabulary{
    background-color: #465A93;
    left:20%;
    width:40%;
    border: 5px;
    margin:10px;
    margin-top:20px;
    color: white;
    font-size: 40px;
    cursor: pointer;
    transition: filter 0.3s ease;
    border-radius: 5px;
}

.example-sentence {
            display: none; /* 默认隐藏 */
            padding: 10px;
            border: 1px solid #ccc;
            margin-top: 10px;
            font-size: 25px;
        }


</style>

<body>
<header id="header">
        <a href="speech_home.php" class="logo">
            <p class="speech_logo">BilingoSpeak</p>
        </a>
        <nav>
            <ul>
                <li class="has-child"><img class="icon" src="three.jpg"> <!--class="in"-->
                    <div>
                        <ul>
                            <div class="pro_icon">
                                <img src="<?php echo $user_icon; ?>">
                                <div class="info">
                                    <p><?php echo $user_name; ?></p>
                                </div>
                            </div>
                            <li class="menu"><a href="ABOUT US.html">Profile</a></li>
                            <li class="menu"><a href="speech_home.php">Home</a></li>
                            <li class="menu"><a href="#">About</a></li>
                            <li class="menu"><a href="編輯畫面.html">Practice</a></li>
                            <li class="menu"><a href="record.php">Record</a></li>
                            <li class="menu"><a href="#">setting</a></li>
                            <li class="menu"><a href="speech_home_before_login.php">LOG OUT</a></li>
                            <br>
                        </ul>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <!--<div class="wall"></div>-->
    <hr class="hr-1">
    <hr class="hr-2">
    <div class="container">
        <div class="middle-column">
            <div class="chat-box">
                <div class="Question-num"><?php echo $phpVariable; ?></div>
                <hr>
                <div><a href="#" onclick="toggleExample('example1')"> <button><?php echo $arr_vocabulary_data[0]; ?></button></a></div>
                <div id="example1" class="example-sentence"><?php echo $arr_Example_sentences_data[0]; ?></div>
                <div><a href="#" onclick="toggleExample('example2')"> <button><?php echo $arr_vocabulary_data[1]; ?></button></a></div>
                <div id="example2" class="example-sentence"><?php echo $arr_Example_sentences_data[1]; ?></div>
                <div><a href="#" onclick="toggleExample('example3')"> <button><?php echo $arr_vocabulary_data[2]; ?></button></a></div>
                <div id="example3" class="example-sentence"><?php echo $arr_Example_sentences_data[2]; ?></div>
                <div><a href="#" onclick="toggleExample('example4')"> <button><?php echo $arr_vocabulary_data[3]; ?></button></a></div>
                <div id="example4" class="example-sentence"><?php echo $arr_Example_sentences_data[3]; ?></div>
                <div><a href="#" onclick="toggleExample('example5')"> <button><?php echo $arr_vocabulary_data[4]; ?></button></a></div>
                <div id="example5" class="example-sentence"><?php echo $arr_Example_sentences_data[4]; ?></div>
                <div><a href="#" onclick="toggleExample('example6')"><button><?php echo $arr_vocabulary_data[5]; ?></button></a></div>
                <div id="example6" class="example-sentence"><?php echo $arr_Example_sentences_data[5]; ?></div>
                <div><a href="#" onclick="toggleExample('example7')"><button><?php echo $arr_vocabulary_data[6]; ?></button></a></div>
                <div id="example7" class="example-sentence"><?php echo $arr_Example_sentences_data[6]; ?></div>

                <div><a href="#" onclick="toggleExample('example8')"><button><?php echo $arr_vocabulary_data[7]; ?></button></a></div>
                <div id="example8" class="example-sentence"><?php echo $arr_Example_sentences_data[7]; ?></div>

                <div><a href="#" onclick="toggleExample('example9')"><button><?php echo $arr_vocabulary_data[8]; ?></button></a></div>
                <div id="example9" class="example-sentence"><?php echo $arr_Example_sentences_data[8]; ?></div>

                <div><a href="#" onclick="toggleExample('example10')"><button><?php echo $arr_vocabulary_data[9]; ?></button></a></div>
                <div id="example10" class="example-sentence"><?php echo $arr_Example_sentences_data[9]; ?></div>

                <div><a href="#" onclick="toggleExample('example11')"><button><?php echo $arr_vocabulary_data[10]; ?></button></a></div>
                <div id="example11" class="example-sentence"><?php echo $arr_Example_sentences_data[10]; ?></div>

                <div><a href="#" onclick="toggleExample('example12')"><button><?php echo $arr_vocabulary_data[11]; ?></button></a></div>
                <div id="example12" class="example-sentence"><?php echo $arr_Example_sentences_data[11]; ?></div>

                <div><a href="#" onclick="toggleExample('example13')"><button><?php echo $arr_vocabulary_data[12]; ?></button></a></div>
                <div id="example13" class="example-sentence"><?php echo $arr_Example_sentences_data[12]; ?></div>

                <div><a href="#" onclick="toggleExample('example14')"><button><?php echo $arr_vocabulary_data[13]; ?></button></a></div>
                <div id="example14" class="example-sentence"><?php echo $arr_Example_sentences_data[13]; ?></div>

                <div><a href="#" onclick="toggleExample('example15')"><button><?php echo $arr_vocabulary_data[14]; ?></button></a></div>
                <div id="example15" class="example-sentence"><?php echo $arr_Example_sentences_data[14]; ?></div>

                <div class="chat-container">                    
                    <!--<div>Best special gift ever received or gave someone.</div>-->
                </div>
                <!--<div><a href="test.php"><button class="start-to-practice">Start to answer</button></a>-->
            </div>
            <div><a href="Vocabulary.php?vdata=<?php echo $phpVariable; ?>"><button class="practicevocabulary">Practice</button></a></div>
            </div>
        </div>
    </div>
        <!--頁尾-->
        <footer>
        <p>@other information</p>
    </footer>

    <script>
    function toggleExample(id) {
        var example = document.getElementById(id);
        example.style.display = (example.style.display === 'none' || example.style.display === '') ? 'block' : 'none';
    }
</script>
</body>

</html>
var resultDiv = document.getElementById('result'); //顯示提示訊息，可刪除
var mediaRecorder;
var recordedChunks = [];
var isRecording = false;
var stream;
const scoreNumber = {
    accuracyScore: 0,
    fluencyScore: 0,
    compScore: 0,
};
const allWords = [];
var currentText = [];
var startOffset = 0;
var recognizedWords = [];
var fluencyScores = [];
var durations = [];
var jo = {};
var textContents = [];
var scoreContents = [];
var orgtext = [];
var pronunciationErrors = [];
var textWithoutPunctuation = [] //不含標點


SPEECH_KEY = "5a248214ebc74d1cbdd37688dd685b77";
SPEECH_REGION = "eastus";
//const referenceText = "The special gift was a letter from my grandparents. It's not so much the letter itself as words of wisdom from my grandparents.";
const referenceText = "The special gift was a letter from my grandparents. It's not so much the letter itself as words of wisdom from my grandparents. They listed the kind of the predicament I am going to face in the following twenty years. It was written in cursive writing of course and looks tattered. It's like the prophecy of my life in the next two decades, totally looks like the clay tablet in The Richest Man in Babylon. Since it was too invaluable, I used to put it in the safe, and now I'm handling it to my kid-kind of reminding them the gestures from their great grandparents and would like them to pass on to their kids and so on.";
const wordsWithPunctuation = referenceText.match(/\b\w+\b|[.,;!?']/g);

function main() {

    startRecording();
    var recordButton = document.getElementById("recordButton");
    recordButton.classList.add('active'); // 添加 active 類別，使按鈕變色並開始閃爍

    const audioConfig = SpeechSDK.AudioConfig.fromDefaultMicrophoneInput();
    var speechConfig = SpeechSDK.SpeechConfig.fromSubscription(SPEECH_KEY, SPEECH_REGION);

    // create pronunciation assessment config
    var pronunciationAssessmentConfig = new SpeechSDK.PronunciationAssessmentConfig(
        referenceText,
        SpeechSDK.PronunciationAssessmentGradingSystem.HundredMark,
        SpeechSDK.PronunciationAssessmentGranularity.Phoneme,
        true
    );

    // setting the recognition language to English.
    speechConfig.speechRecognitionLanguage = "en-US";

    // create the speech recognizer
    var recognizer = new SpeechSDK.SpeechRecognizer(speechConfig, audioConfig);
    pronunciationAssessmentConfig.applyTo(recognizer);

    recognizer.startContinuousRecognitionAsync(); //Start continuous recognition

    recognizer.recognized = function (s, e) {
        if (e.result.reason === SpeechSDK.ResultReason.RecognizedSpeech) {
            var pronunciationResult = SpeechSDK.PronunciationAssessmentResult.fromResult(e.result);
            var pa = pronunciationResult.accuracyScore;
            var pp = pronunciationResult.pronunciationScore;
            var pc = pronunciationResult.completenessScore;
            var pf = pronunciationResult.fluencyScore;
            scoreContents.push([pa, pp, pc, pf]); //將textContent添加到陣列中
            var recognizedText = e.result.text; // 儲存識別的原始文本
            orgtext.push(recognizedText);
            console.log("pronunciation assessment for: ", e.result.text);
            console.log(" Accuracy score: ", pronunciationResult.accuracyScore, '\n',
                "pronunciation score: ", pronunciationResult.pronunciationScore, '\n',
                "completeness score : ", pronunciationResult.completenessScore, '\n',
                "fluency score: ", pronunciationResult.fluencyScore,
            );


            console.log("  Word-level details:");
            pronunciationResult.detailResult.Words.forEach((word, idx) => {
                var textContent = word.Word + " ";
                word.PronunciationAssessment.AccuracyScore
                textContents.push([textContent, word.PronunciationAssessment.AccuracyScore]);
                console.log("    ", idx + 1, ": word: ", word.Word, "accuracy score: ", word.PronunciationAssessment.AccuracyScore, "error type: ", word.PronunciationAssessment.ErrorType, ";");
            });
            //recognizer.close();


            recordButton.addEventListener("click", function () {
                stopRecording();
                recordButton.classList.remove('active'); //移除 active 類別，停止閃爍
                saveScore();
                recognizer.stopContinuousRecognitionAsync(); // 停止連續識別
            });
        }
    };
}

async function startRecording() {
    try {
        recordedChunks = [];// 重置錄音數據陣列
        stream = await navigator.mediaDevices.getUserMedia({
            audio: true
        });
        mediaRecorder = new MediaRecorder(stream);

        mediaRecorder.ondataavailable = function (event) {
            if (event.data.size > 0) {
                recordedChunks.push(event.data);
            }
        };

        mediaRecorder.onstop = function () {
            isRecording = false;
            saveRecording();
        };

        mediaRecorder.start();
        isRecording = true;
    } catch (error) {
        resultDiv.textContent = '無法獲取麥克風訪問權限: ' + error.message;
    }
}

function stopRecording() {
    mediaRecorder.stop();
    stream.getTracks().forEach(track => track.stop());
}

function saveRecording() {
    var blob = new Blob(recordedChunks,
        {
            type: 'audio/ogg'
        });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'recorded_data.ogg';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);
    /*var saved = document.getElementById('result');
    saved.textContent = "錄音已完成並儲存至\"我的練習\"。";*/
}


//測試用的
function saveScore() {
    var scorebutton = document.getElementById("scoreButton");
    console.log("Received textContentsArray: ", textContents);


    scorebutton.addEventListener("click", function () {
        var rightcolumn = document.getElementById("right-column");
        rightcolumn.innerHTML = `
        <div class="info">
            <!--左側區塊-->
            <div>
                <div class="score-image-container">
                    <span id="pronunciationScore">100%</span>
                </div>
                <p>Pronunciation<br>Score</p>
            </div>
            <div>
                <div class="score-image-container">
                    <span id="accuracyScore"></span>
                </div>
                <p>Accuracy<br>Score</p>
            </div>    
            <div>
                <div class="score-image-container">
                    <span id="completenessScore"></span>
                </div>
                <p>Completeness<br>Score</p>
            </div>    
            <div>
                <div class="score-image-container">
                    <span id="fluencyScore"></span>
                </div>
                <p>Fluency<br>Score</p>
            </div>
        </div>
        <hr>
        <p class="notice">You should improve your pronunciation of the following words:</p>
            <div class="chat-box-score">
                <div class="chat-container">
                    <div id="content">
                    </div>
                    <div id="ha"></div>
                </div>
            </div>
            <a href="test.php"><button id="again_button">Try again!</button></a>
        </div>
`;
        var accuracyScoreElement = document.getElementById('accuracyScore');
        var pronunciationScoreElement = document.getElementById('pronunciationScore');
        var completenessScoreElement = document.getElementById('completenessScore');
        var fluencyScoreElement = document.getElementById('fluencyScore');

        var totalAccuracyScore = 0; //用來總和所有第一個元素的值
        var totalpronunciationScore = 0;
        var totalcompletenessScore = 0;
        var totalfluencyScore = 0;
        var count = 0; // 用來記錄迭代的次數

        for (var scorerow of scoreContents) {
            var allpa = scorerow[0]; // 獲取每一列的第一個元素
            var allpp = scorerow[1]; // 获取每一列的第二个元素
            var allpc = scorerow[2];
            var allpf = scorerow[3];

            // 將每一列的第一個元素的值添加到總和變數中
            totalAccuracyScore += allpa;
            totalpronunciationScore += allpp;
            totalcompletenessScore += allpc;
            totalfluencyScore += allpf;

            count++;
        }

        // 計算平均值
        var averageAccuracyScore = (totalAccuracyScore / count).toFixed(1);
        var averagepronunciationScore = (totalpronunciationScore / count).toFixed(1);
        var averagecompletenessScore = (totalcompletenessScore / count).toFixed(1);
        var averagefluencyScore = (totalfluencyScore / count).toFixed(1);


        accuracyScoreElement.textContent = averageAccuracyScore;
        pronunciationScoreElement.textContent = averagepronunciationScore;//整體分數
        completenessScoreElement.textContent = averagecompletenessScore;
        fluencyScoreElement.textContent = averagefluencyScore;

        var content = document.getElementById("content");
        var fragment = document.createDocumentFragment();

        /*for (var row of textContents) {
            var firstElement = row[0]; // 获取每一列的第一个元素
            var secondElement = row[1]; // 获取每一列的第二个元素

            if (secondElement < 90) {
                let div = document.createElement("div");
                let button = document.createElement("button");
                div.classList.add('advise');
                button.id = 'listen-button';
                div.appendChild(document.createTextNode(firstElement));
                div.appendChild(button);
                fragment.appendChild(div);
            }
        }*/

        for (var row of textContents) {
            var firstElement = row[0]; // 获取每一列的第一个元素
            var secondElement = row[1]; // 获取每一列的第二个元素


            // 创建一个新的 <span> 元素
            let span = document.createElement("span");
            span.classList.add('speaking-text');

            if (secondElement < 90) {
                span.classList.add('speaking-text-wrong');
            }
        }

        let i = 0;

        for (const row of textContents) {
            const wordWithPunctuation = wordsWithPunctuation[i];
            var eachscore = row[1];
            const wordWithoutPunctuation = row[0];
            // 模拟发音评分，这里假设 "gift" 是一个发音错误的单词
            if (eachscore < 80) {
                pronunciationErrors.push(i);
            }


            i++; // 计数器递增
            if (i >= wordsWithPunctuation.length) {
                break; // 如果 i 达到或超过 wordsWithPunctuation 的长度，退出循环
            }
        }

        // 标记发音错误的单词为红色
        const markedText = referenceText
            .split(' ')
            .map((word, index) => {
                let span = document.createElement("span");
                span.classList.add('speaking-text');
                if (pronunciationErrors.includes(index)) {
                    span.classList.add('speaking-text-wrong');
                }
                span.appendChild(document.createTextNode(word + ' '));
                fragment.appendChild(span);
            })

        /*for (var row of textContents) {
            var firstElement = row[0]; // 获取每一列的第一个元素
            var secondElement = row[1]; // 获取每一列的第二个元素

            if (secondElement < 90) {
                let div = document.createElement("div");
                let button = document.createElement("button");
                div.classList.add('advise');
                button.id = 'listen-button';
                div.appendChild(document.createTextNode(firstElement));
                div.appendChild(button);
                fragment.appendChild(div);
            }
        }*/


        while (fragment.firstChild) {
            content.appendChild(fragment.firstChild);
        }

        // 遍历所有具有 "speaking-text-wrong" 类的单词
        const speakingtextwrong = document.querySelectorAll('.speaking-text-wrong');
        speakingtextwrong.forEach(word => {
            word.addEventListener('click', () => {
                // 播放正确的发音
                console.log("hallo");
                const audio = new Audio("letter.mp3");
                audio.play();
            });
        });
    });
}



const dataFromServer = {
  1: [
    { score: "50", answerTime: "2023-09-09T10:00:00Z" },
    { score: "60", answerTime: "2023-09-09T10:30:00Z" },
    { score: "70", answerTime: "2023-09-09T11:00:00Z" },
    { score: "50", answerTime: "2023-09-10T10:00:00Z" },
    { score: "60", answerTime: "2023-09-10T10:30:00Z" },
    { score: "70", answerTime: "2023-09-10T11:00:00Z" }
  ],
  2: [
    { score: "40", answerTime: "2023-09-09T10:15:00Z" },
    { score: "50", answerTime: "2023-09-09T10:45:00Z" },
    { score: "60", answerTime: "2023-09-09T11:15:00Z" }
  ]
};
const ctx = document.getElementById("myChart").getContext("2d");

let chart;
function updateChart() {
  if (chart) {
    chart.destroy();
  }

  const question = document.getElementById("questionSelect").value;
  const dataForQuestion = dataFromServer[question];

  // const barWidth = 30; // 定義每個bar的寬度
  const labels = [];
  const dataset = [];

  for (let item of dataForQuestion) {
    labels.push(moment(item.answerTime).format("YYYY-MM-DD HH:mm:ss"));
    dataset.push(item.score);
  }

  // // 計算canvas的寬度
  // const totalWidth = dataForQuestion.length * barWidth;
  // document.getElementById("myChart").width = totalWidth;

  chart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [
        {
          label: "成績",
          data: dataset,
          backgroundColor: "#3e95cd",
          borderColor: "rgba(54, 162, 235, 1)",
          borderWidth: 1.5
        }
      ]
    },
    options: {
      scales: {
        x: {
          type: "category",
          ticks: {
            autoSkip: false
          }
        },
        y: {
          beginAtZero: true,
          max: 100
        }
      }
    }
  });
}

document.addEventListener("DOMContentLoaded", function () {
  updateChart();
});

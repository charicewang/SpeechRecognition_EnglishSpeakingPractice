<?php
echo $_GET['new'];
?>
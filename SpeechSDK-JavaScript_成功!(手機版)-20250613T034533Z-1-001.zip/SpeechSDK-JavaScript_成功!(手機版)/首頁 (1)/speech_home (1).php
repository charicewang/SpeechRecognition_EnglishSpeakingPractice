<!DOCTYPE html>

<html lang="ja">
<head>
<meta charset="utf-8">
<meta name = "viewport" content="width=device-width, initial-scale=1"/>
<title>Speech_Home</title>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/Modaal/0.4.4/css/modaal.min.css">

<link rel="stylesheet" type="text/css" href="STYLE2.css">
<link rel="stylesheet" type="text/css" href="header.css">

</head>

<body>
    <!--font-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&family=Raleway:wght@200&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.0.min.js"></script>

 

    <header id="header">
        <a href="">
            <p class="speech_logo">Logo</p>
        </a>
        <nav>
            <ul>
                <li id="Home"><a href="">
                        <p><b>Home</b></p>
                    </a></li>
                <li id="About"><a href="">
                        <p><b>About</b></p>
                    </a></li>
                <li id="Logout"><a href="">
                        <p><b>Logout</b></p>
                    </a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="big_pic"></section>        
        <section id="map">
            
            <div class= "flex_container">
                <div class= "place">
                    <a href="#log_in" class="modal-open">
                        <div class="button-container">
                            <div>
                                <a href="score.html" class="image-link"><button class="image-button"></button></a>
                                <a href="score.html" class="image-link2"><button class="image-button2">START PRACTICE</button></a>
                            </div>
                        </div>
                    </a>        
                </div>

                <div class= "place">
                    <a href="#log_in" class="modal-open">
                        <div class="button-container">
                            <div>
                                <a href="score.html" class="image-link"><button class="image-button"></button></a>
                                <a href="score.html" class="image-link2"><button class="image-button2">PROGRESS TRACKING</button></a>
                            </div>
                        </div>
                    </a>        
                </div>

                <div class= "place">
                    <a href="#log_in" class="modal-open">
                        <div class="button-container">
                            <div>
                                <a href="score.html" class="image-link"><button class="image-button"></button></a>
                                <a href="score.html" class="image-link2"><button class="image-button2">COMMUNITY</button></a>
                            </div>
                        </div>
                        <p></p>
                    </a>
                </div>
            </div>
        </section>
    </main>

    <!--頁尾-->
    <footer>
        <!--按下去會回到最上方的小箭頭
        <a href="#top" id="back_to_top">
            <img src= "up.png">
        </a>-->
    </footer>

    <script src="jquery-3.6.0.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <!--GALLERY-->
    <script src="https://unpkg.com/web-animations-js@2.3.2/web-animations.min.js"></script>
    <script src="https://unpkg.com/muuri@0.8.0/dist/muuri.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
    <!--SLIDE_SHOW-->
    <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

    <!--LOG IN-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Modaal/0.4.4/js/modaal.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.js"></script>
    <script src="login_motion.js"></script>

    <script src="js.js"></script>
</body>
</html>


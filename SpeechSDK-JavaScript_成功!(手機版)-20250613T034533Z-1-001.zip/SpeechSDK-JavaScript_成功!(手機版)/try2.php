<?php

        mb_internal_encoding("UTF-8");
        $score_phpVariable = 'School_and_Studying';
        $host = 'localhost';
        $dbuser ='root';
        $dbpassword = '0000';
        $dbname = 'EnglishSpeakingTrainingApp';
        $conn = mysqli_connect($host,$dbuser,$dbpassword,$dbname);
        // 创建数据库连接

        // 检查连接是否成功
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // 构造 SQL 查询字符串
        //$stmt = $conn->prepare("SELECT * FROM user_score WHERE username = $user_name AND scoretype = :scoretype");
        $stmt = $conn->query("SELECT * FROM user_score WHERE username = 'sid01'");
        ?>
<?php
// 假设这些数据是从前端获取的
$username = 'ha';
$averageAccuracyScore = ''; // 请替换为实际的数据
$averagepronunciationScore = ''; // 请替换为实际的数据
$averagecompletenessScore = ''; // 请替换为实际的数据
$averagefluencyScore = ''; // 请替换为实际的数据

mb_internal_encoding("UTF-8");
$host = 'localhost';
$dbuser ='root';
$dbpassword = '0000';
$dbname = 'EnglishSpeakingTrainingApp';
$conn = mysqli_connect($host,$dbuser,$dbpassword,$dbname);
// 创建数据库连接

// 检查连接是否成功
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 构造 SQL 查询字符串
$sql = "INSERT INTO user_score (scoreid, username, averageAccuracyScore, averagepronunciationScore, averagecompletenessScore, averagefluencyScore, date_time) VALUES ('', '$username', '$averageAccuracyScore', '$averagepronunciationScore', '$averagecompletenessScore', '$averagefluencyScore', NOW())";

// 执行 SQL 查询
if ($conn->query($sql) === TRUE) {
    echo "Data inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// 关闭数据库连接
$conn->close();
?>

<?php
session_start();  //很重要，可以用的變數存在session裡
/*$user_id = $_SESSION["id"];*/
$user_icon = $_SESSION["icon"];
$user_name = $_SESSION["name"];
/*$user_intro = $_SESSION["intro"];
$user_occu = $_SESSION["occu"];*/

mb_internal_encoding("UTF-8");
$vphpVariable = $_GET['vdata'];
//連結資料庫
$link = new PDO("mysql:dbname=EnglishSpeakingTrainingApp;host=localhost","root","0000");

$stmt = $link->prepare("SELECT * FROM vocabulary_question WHERE vqtype = :vqtype");

// 繫結參數
$stmt->bindParam(':vqtype', $vphpVariable, PDO::PARAM_STR);
   
// 執行查詢
$stmt->execute();
   
// 取得結果
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$i = 0;
foreach ($result as $row) {
    // 處理每一列的資料
    $arr_vocabulary_description[$i] = $row['vq_description'];
    $arr_option1_data[$i] = $row['option1']; 
    $arr_option2_data[$i] = $row['option2']; 
    $arr_option3_data[$i] = $row['option3']; 
    $arr_option4_data[$i] = $row['option4'];   
    ++$i;
}

$ophpVariable = $_GET['vdata'];
$stmt1 = $link->prepare("SELECT * FROM optiontext WHERE otype = :otype");

// 繫結參數
$stmt1->bindParam(':otype', $ophpVariable, PDO::PARAM_STR);
   
// 執行查詢
$stmt1->execute();
   
// 取得結果
$result1 = $stmt1->fetchAll(PDO::FETCH_ASSOC);

$i1 = 0;
foreach ($result1 as $row) {
    // 處理每一列的資料
    $arr_option_text[$i1] = $row['option_text'];
    $arr_translation[$i1] = $row['translation'];  
    ++$i1;
}
?>

<!DOCTYPE html>
<html lang="ja">


<head>
    <meta charset="UTF-8">
    <title>Speaking practice</title>
    <link rel="stylesheet" type="text/css" href="header.css">
    <link rel="stylesheet" type="text/css"
        href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
    <link rel="stylesheet" type="text/css"
        href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-2-9/css/5-2-9.css">
</head>

<script>var a = 1;</script>

<style>
    footer {
        background-color: gainsboro;
        margin: 0px;
        padding: 1%;
        text-align: center;
    }
    /* 定義三欄佈局的容器 */
    .container {
        display: flex;
        height:100%;
    }

    /*成績顯示*/
    .info {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        max-height:300px;
    }

    .score-text {
        font-size: 40px;
        font-weight: bold;
    }

    .score-image-container {
        margin: 15px;
        margin-top:-40px;
        display: flex;
        width: 160px;
        height: 160px;
        position: relative;
        /*top: 50%;*/
        /*left: 30%;*/
        border-radius: 50%;
        border: 10px solid #465A93;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
        justify-content: center;
        /* 水平居中 */
        align-items: center;
        /* 垂直居中 */
        font-size: 40px;
        font-weight: bolder;
        background-color: #F0EEE2;
    }

    .score-image-container span{
        font-size:50px;
    }

    .info div p {
    text-align: center;
    font-weight: bolder;
    font-size:30px;
}



    /* 中間分栏的樣式 */
    .middle-column {
        flex: 2;
        width: 20%;
        background-color: #E8E7E7;
        min-height: 600px;
        height:1500px;
    }

    /* 中間分栏區隔的樣式 */
    .middle-separator {
        border-left: 1px solid #ccc;
        border-right: 1px solid #ccc;
        padding-left: 30px;
        padding-right: 30px;
        padding-bottom: 30px;
    }

    hr {
        position: static;
    }


    .question-button {
        padding: 15px 15px;
        border-radius: 25px;
        width: 90%;
        text-align: left;
        font-size: 20px;
        background-color: #fff;
        border: 1px solid #ccc;
        margin-bottom: 20px;
        cursor: pointer;
    }

    .record-button-container {
        display: flex;
        justify-content: center;
        margin-bottom: 0px;
        margin-top: 20px;
        background-color: #CCEBF3;
    }

    .record-button-container div {
        position: absolute;
        top: 93%;
    }

    #recordButton {
        background-color: #CCEBF3;
    }

    /* 按鈕樣式 */
    .guide-button {
        padding: 15px 15px;
        width: 100%;
        text-align: left;
        font-size: 20px;
        background-color: #465A93;
        color: #fff;
        border: 1px solid #465A93;
        cursor: pointer;
    }

    .guide-button:hover {
        background-color: #8C52FF;
    }

    .guide-container {
        position: absolute;
        width: 100%;
        left: 0%;
        top: 40%;
    }

    .info div p {
        text-align: center;
        font-weight: bolder;
    } 

    .speaking-text {
        color: blue;
    }

    .speaking-text-wrong {
        color: red;
        cursor: pointer; /* 鼠标指针显示为手型，表示可以点击 */
    }

    .notice {
        text-align:left;
        font-size:40px;
    }

    .advise{
        margin:20px;
        font-size:30px;
    }


    .container-option {
        padding: 1rem;
    }

    .speech_logo {
        font-size: 50px;
        font-weight: bold;
        text-align:center;
        /*position: absolute;
        right:5%;*/

        /*color: orange;*/
    }

    body {
    margin: 0;
    padding: 0;
    background-color: #f5f5f5;
    text-align: center;
    }

main {
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    height:1500px;
}

/* 按鈕 */
button {
    background-color: #465A93;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    width:500px;
    height:100px;
    font-size: 50px;
    position: relative;
    top:100px;
}

/* 題目文本 */
h2 {
    font-size: 60px;
    margin-bottom: 20px;
}

h3{
    font-size: 40px;
    margin-bottom: 20px;
}

/* 選項 */
form {
    margin-top:40px;
    text-align: left;
}

input[type="radio"] {
    margin-right: 10px;
    zoom:3;
}

label {
    cursor: pointer;
    font-size:60px;
}

/* 結果頁面 */
p {
    font-size: 18px;
}

.score-info{
    height:100px;
    font-size:20px;
}

.red{
    color:red;

}

.blue{
    color:blue;
}

.youranswer{
    font-size:30px;
    margin:10px;
}

.correctanswer{
    font-size:30px;
    margin:10px;
    font-weight: bold;
    background-color: lightblue;
}

.answer-content{
    background-color: #F0EEE2;
    margin:20px;
}

.allcontent{
    background-color: #E8E7E7;
    padding:10px;
    height:900px;
    overflow: auto;
}

#again_button{
    position: relative;
    background-color: #465A93;
    color: white;
    border-radius: 12%;
    left: 50%;
    bottom:-10%;
    width: 200px;
    height: 60px;
    /*border-radius: 30%;*/
    background-size: cover;
    border: none;
    cursor: pointer;
    transform: translateX(-50%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size:30px;
}

</style>


<body>
<header id="header">
        <a href="speech_home.php" class="logo">
            <p class="speech_logo">BilingoSpeak</p>
        </a>
        <nav>
            <ul>
                <li class="has-child"><img class="icon" src="three.jpg"> <!--class="in"-->
                    <div>
                        <ul>
                            <div class="pro_icon">
                                <img src="<?php echo $user_icon; ?>">
                                <div class="info">
                                    <p><?php echo $user_name; ?></p>
                                </div>
                            </div>
                            <li class="menu"><a href="ABOUT US.html">Profile</a></li>
                            <li class="menu"><a href="speech_home.php">Home</a></li>
                            <li class="menu"><a href="#">About</a></li>
                            <li class="menu"><a href="編輯畫面.html">Practice</a></li>
                            <li class="menu"><a href="record.php">Record</a></li>
                            <li class="menu"><a href="#">setting</a></li>
                            <li class="menu"><a href="speech_home_before_login.php">LOG OUT</a></li>
                            <br>
                        </ul>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <hr class="hr-1">
    <hr class="hr-2">
    <main>
        <h2>Question1</h2>
        <h3><?php echo $arr_vocabulary_description[0]; ?></h3>
        <form>
            <input type="radio" name="answer" value="0" id="option1">
            <label for="option1">special</label><br>
            <input type="radio" name="answer" value="1" id="option2">
            <label for="option2">選項2</label><br>
            <input type="radio" name="answer" value="2" id="option3">
            <label for="option3">選項3</label><br>
            <input type="radio" name="answer" value="3" id="option4">
            <label for="option4">選項4</label><br>
        </form>
        <div id="scoreinfo">

        </div>

        
        <button onclick="nextQuestion()">Next</button>
        <button onclick="showResult()" style="display: none;">查看结果</button>
    </main>
    <footer>
        <p>&copy;選擇題</p>
    </footer>
</body>
<!--<script src="Vocabulary1.js"></script>-->
<script>
    var jsVariable1 = <?php echo json_encode($arr_option1_data[0]); ?>;
    var jsVariable2 = <?php echo json_encode($arr_option2_data[0]); ?>;
    var jsVariable3 = <?php echo json_encode($arr_option3_data[0]); ?>;
    var jsVariable4 = <?php echo json_encode($arr_option4_data[0]); ?>;                                                   
    var jsVariable5 = <?php echo json_encode($arr_option1_data[1]); ?>;
    var jsVariable6 = <?php echo json_encode($arr_option2_data[1]); ?>;
    var jsVariable7 = <?php echo json_encode($arr_option3_data[1]); ?>;
    var jsVariable8 = <?php echo json_encode($arr_option4_data[1]); ?>;
    var jsVariable9 = <?php echo json_encode($arr_option1_data[2]); ?>;
    var jsVariable10 = <?php echo json_encode($arr_option2_data[2]); ?>;
    var jsVariable11 = <?php echo json_encode($arr_option3_data[2]); ?>;
    var jsVariable12 = <?php echo json_encode($arr_option4_data[2]); ?>;

    var jsVariable13 = <?php echo json_encode($arr_option1_data[3]); ?>;
    var jsVariable14 = <?php echo json_encode($arr_option2_data[3]); ?>;
    var jsVariable15 = <?php echo json_encode($arr_option3_data[3]); ?>;
    var jsVariable16 = <?php echo json_encode($arr_option4_data[3]); ?>;
    var jsVariable17 = <?php echo json_encode($arr_option1_data[4]); ?>;
    var jsVariable18 = <?php echo json_encode($arr_option2_data[4]); ?>;
    var jsVariable19 = <?php echo json_encode($arr_option3_data[4]); ?>;
    var jsVariable20 = <?php echo json_encode($arr_option4_data[4]); ?>;

    console.log(jsVariable1);
    console.log(jsVariable2);
    console.log(jsVariable3);
    console.log(jsVariable4);
    console.log(jsVariable5);

    const questions = [
    {
        question: "Question1",
        options: [jsVariable1, jsVariable2, jsVariable3, jsVariable4],
        correctAnswer: 1
    },
    {
        question: "Question2",
        options: [jsVariable5, jsVariable6, jsVariable7, jsVariable8],
        correctAnswer: 2
    },
    {
        question: "Question3",
        options: [jsVariable9, jsVariable10, jsVariable11, jsVariable12],
        correctAnswer: 2
    },
    {
        question: "Question4",
        options: [jsVariable13, jsVariable14, jsVariable15, jsVariable16],
        correctAnswer: 3
    },
    {
        question: "Question5",
        options: [jsVariable17, jsVariable18, jsVariable19, jsVariable20],
        correctAnswer: 3
    },

];

let currentQuestionIndex = 0;
let userScore = 0;
let currentQuestioncontent_num = 0;
let j = 1;
var correctAnswerElement1 = [];
let currentQuestioncontent = [<?php echo json_encode($arr_vocabulary_description[0]); ?>,
                            <?php echo json_encode($arr_vocabulary_description[1]); ?>,
                            <?php echo json_encode($arr_vocabulary_description[2]); ?>,
                            <?php echo json_encode($arr_vocabulary_description[3]); ?>,
                            <?php echo json_encode($arr_vocabulary_description[4]); ?>];

const questionText = document.querySelector('h2');
const questioncontent = document.querySelector('h3');
const optionsForm = document.querySelector('form');
const nextButton = document.querySelector('button');
const resultButton = document.querySelectorAll('button')[1];
const score = document.getElementById('scoreinfo');

function displayQuestion() {
    if (currentQuestionIndex < questions.length) {
        questionText.textContent = questions[currentQuestionIndex].question;
        questioncontent.textContent = currentQuestioncontent[currentQuestioncontent_num];
        optionsForm.innerHTML = "";

        questions[currentQuestionIndex].options.forEach((option, index) => {
            const input = document.createElement('input');
            input.type = "radio";
            input.name = "answer";
            input.value = index;
            input.id = `option${index}`;
            const label = document.createElement('label');
            label.setAttribute('for', `option${index}`);
            label.textContent = option;

            optionsForm.appendChild(input);
            optionsForm.appendChild(label);
            optionsForm.appendChild(document.createElement('br'));
        });
    } else {

        showResult();
    }
}

function nextQuestion() {
    const selectedOption = document.querySelector('input[name="answer"]:checked');

    if (selectedOption) {
        const userAnswer = parseInt(selectedOption.value);

        if (userAnswer === questions[currentQuestionIndex].correctAnswer) {
            userScore++;
            console.log(`回答問題正確！`);
            correctAnswerElement1.push(j);
            //correctAnswerElement1.classList.add("blue");
        }
        else {
        console.log(`回答問題錯誤，正確答案是選項 ${questions[currentQuestionIndex].correctAnswer}。`);
        correctAnswerElement1.push(0);
    }

        j++;
        currentQuestionIndex++;
        currentQuestioncontent_num++;

        if (currentQuestionIndex === questions.length) {
            nextButton.style.display = "none";
            resultButton.style.display = "block";
        }

        displayQuestion();
    }
}

function showResult() {
    const totalQuestions = questions.length;
    const percentage = (userScore / totalQuestions) * 100;

    //questionText.textContent = "Your score:";
    //score.innerHTML = `您的分數：${userScore} / ${totalQuestions}<br>百分比：${percentage}%`;
    score.innerHTML = `<div class="info">
    <!--左側區塊-->
    <div>
        <div class="score-image-container">
            <span id="iscorrect"></span>
        </div>
    </div>
    <div>
        <div class="score-image-container">
            <span id="scorepercen"></span>
        </div>
    </div>    
</div>
<hr>
<p class="notice">Your Answer:</p>
    <div class = "allcontent"><div class = "answer-content">
        <div class = "youranswer">
            1. <?php echo json_encode($arr_option_text[0]); ?>
            <!--1. The author takes great care to maintain the <span class="youranswer_content1">authenticity</span> of the time period, incorporating accurate historical details and language.-->
        </div>
        <div class = "correctanswer">
            翻譯: <?php echo json_encode($arr_translation[0]); ?>
        </div>
    </div>

    <div class = "answer-content">
        <div class = "youranswer">
            2. <?php echo json_encode($arr_option_text[1]); ?>
        </div>
        <div class = "correctanswer">
            翻譯: <?php echo json_encode($arr_translation[1]); ?>
        </div>
    </div>

    <div class = "answer-content">
        <div class = "youranswer">
            3. <?php echo json_encode($arr_option_text[2]); ?>
        </div>
        <div class = "correctanswer">
            翻譯: <?php echo json_encode($arr_translation[2]); ?>
        </div>
    </div>

    <div class = "answer-content">
        <div class = "youranswer">
            4. <?php echo json_encode($arr_option_text[3]); ?>
        </div>
        <div class = "correctanswer">
            翻譯: <?php echo json_encode($arr_translation[3]); ?>
        </div>
    </div>

    <div class = "answer-content">
        <div class = "youranswer">
            5. <?php echo json_encode($arr_option_text[4]); ?>
        </div>
        <div class = "correctanswer">
            翻譯: <?php echo json_encode($arr_translation[4]); ?>
        </div>
    </div></div>
    
    <div class="chat-box-score">
        <div class="chat-container">
            <div id="content">
            </div>
            <div id="ha"></div>
        </div>
    </div>
    <a href="Vocabularyoption.php"><button id="again_button">Try again!</button></a>
</div>`;
    const iscorrect = document.getElementById('iscorrect');
    score.className = "score-info";
    iscorrect.textContent = userScore + "/" + totalQuestions;
    const scorepercen = document.getElementById('scorepercen');
    scorepercen.textContent = percentage + "%";
    resultButton.style.display = "none";
    questioncontent.style.display = "none";
    optionsForm.style.display = "none";
    questionText.style.display = "none";
    for (var z = 0; z < 5; z++) {
        //console.log(correctAnswerElement1[z]);
        if(correctAnswerElement1[z] === z+1) {
            console.log(correctAnswerElement1[z]);
            var z1=z+1;
            var correctAnswerElements2 = document.querySelector(".youranswer_content" + z1);
            correctAnswerElements2.classList.add("blue");
        }
        else{
            var z1=z+1;
            var correctAnswerElements2 = document.querySelector(".youranswer_content" + z1);
            correctAnswerElements2.classList.add("red");
        }
        
    }
}

displayQuestion();
</script>

</html>
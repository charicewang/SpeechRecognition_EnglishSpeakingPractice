-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2023-11-25 04:48:03
-- 伺服器版本： 10.4.27-MariaDB
-- PHP 版本： 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `englishspeakingtrainingapp`
--

-- --------------------------------------------------------

--
-- 資料表結構 `optiontext`
--

CREATE TABLE `optiontext` (
  `oID` int(11) NOT NULL,
  `otype` varchar(200) NOT NULL,
  `option_text` varchar(200) NOT NULL,
  `translation` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `optiontext`
--

INSERT INTO `optiontext` (`oID`, `otype`, `option_text`, `translation`) VALUES
(1, 'A', 'The author takes great care to maintain the <span class=\"youranswer_content1\">authenticity</span> of the time period, incorporating accurate historical details and language.', '作者非常注重保持時代的真實性，並融入了準確的歷史細節和語言。'),
(2, 'A', 'The politician was able to <span class=\"youranswer_content2\">articulate</span> her policy positions in a clear and concise manner.', '這位政治人物能夠以清晰簡潔的方式表達她的政策立場。'),
(3, 'A', 'She <span class=\"youranswer_content3\">advocate</span> for stronger environmental regulations to protect the planet.', '她倡導加強環保法規以保護地球。'),
(4, 'A', 'He <span class=\"youranswer_content4\">asserted</span> that his theory was backed by substantial evidence.', '他斷言他的理論有實質的證據支持。'),
(5, 'A', 'The company is investing heavily in <span class=\"youranswer_content5\">Artificial intelligence</span> to improve their customer service.', '公司正在大力投資於人工智慧，以提升他們的客戶服務。'),
(6, 'B', 'The author emphasizes the importance of preserving the <span class=\"youranswer_content1\">brevity</span> of the story, avoiding unnecessary details that might detract from its essence.', '作者強調保存故事的簡潔，避免不必要的細節可能削弱其本質。'),
(7, 'B', 'The speaker\'s ability to <span class=\"youranswer_content2\">blend</span> humor with serious topics captivated the audience, creating an engaging and enjoyable presentation.', '演講者將幽默與嚴肅的主題融合的能力迷住了聽眾，創造出引人入勝且愉快的演講。'),
(8, 'B', 'Environmentalists <span class=\"youranswer_content3\">bolster</span> their arguments with scientific evidence, aiming to raise awareness about the urgent need for conservation.', '環保人士用科學證據支持他們的論點，旨在提高對保育迫切需求的意識。'),
(9, 'B', 'The CEO <span class=\"youranswer_content4\">bolstered</span> the team\'s morale by acknowledging their hard work and expressing confidence in their ability to overcome challenges.', 'CEO通過承認團隊的辛勤工作並表達對他們克服挑戰的信心，增強了團隊的士氣。'),
(10, 'B', 'The IT department implemented a new <span class=\"youranswer_content5\">backup</span> system to ensure the security and retrieval of important data in case of unexpected incidents.', 'IT部門實施了一個新的備份系統，以確保在意外事件發生時能夠安全檢索重要數據。'),
(11, 'C', 'The author emphasizes the importance of preserving the <span class=\"youranswer_content1\">comprehensive</span> nature of the story, avoiding unnecessary details that might detract from its essence.', '作者強調保存故事的全面性，避免不必要的細節可能削弱其本質。'),
(12, 'C', 'The speaker\'s ability to <span class=\"youranswer_content2\">captivate</span> the audience by blending humor with serious topics created an engaging and enjoyable presentation.', '演講者將幽默與嚴肅的主題巧妙融合的能力迷住了聽眾，創造出引人入勝且愉快的演講。'),
(13, 'C', 'Environmentalists <span class=\"youranswer_content3\">conserve</span> their arguments with scientific evidence, aiming to raise awareness about the urgent need for conservation.', '環保人士用科學證據支持他們的論點，旨在提高對保育迫切需求的意識。'),
(14, 'C', 'The CEO <span class=\"youranswer_content4\">confidence</span> in the team\'s ability to overcome challenges bolstered their morale by acknowledging their hard work.', 'CEO通過承認團隊的辛勤工作並表達對他們克服挑戰的信心，增強了團隊的士氣。'),
(15, 'C', 'The IT department implemented a new <span class=\"youranswer_content5\">critical</span> backup system to ensure the security and retrieval of important data in case of unexpected incidents.', 'IT部門實施了一個新的關鍵備份系統，以確保在意外事件發生時能夠安全檢索重要數據。'),
(16, 'D', 'The <span class=\"youranswer_content1\">diligent</span> writer spent hours perfecting each sentence, ensuring the quality and precision of the manuscript. ', '這位勤奮的作家花了數小時完善每一句話，確保手稿的質量和精確性。'),
(17, 'D', 'The team <span class=\"youranswer_content2\">dynamic</span> was evident during the brainstorming session, as members collaborated seamlessly to generate innovative ideas. ', '在腦力激盪會議上，團隊的活力顯而易見，成員們無縫協作，提出創新的想法。'),
(18, 'D', 'The <span class=\"youranswer_content3\">determined</span> activists tirelessly campaigned for social justice, inspiring others to join their cause.', '這些堅定的活動家不懈地為社會正義進行運動，激勵其他人加入他們的事業。'),
(19, 'D', 'In the face of adversity, the leader\'s <span class=\"youranswer_content4\">decisiveness</span> and quick thinking guided the team to overcome challenges and achieve success.', '面對逆境，領導者的果斷和迅速的思考引導團隊克服挑戰，取得成功。'),
(20, 'D', 'The company adopted a <span class=\"youranswer_content5\">data-driven</span> approach, relying on analytics to make informed decisions and drive business growth.', '公司採用了以數據為基礎的方法，依靠分析進行明智的決策，推動業務增長。');

-- --------------------------------------------------------

--
-- 資料表結構 `question`
--

CREATE TABLE `question` (
  `qID` int(11) NOT NULL,
  `qtype` varchar(1000) NOT NULL,
  `question_describtion` varchar(200) NOT NULL,
  `text_content` varchar(2000) NOT NULL,
  `translation` varchar(2000) NOT NULL,
  `audio_file_location` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `question`
--

INSERT INTO `question` (`qID`, `qtype`, `question_describtion`, `text_content`, `translation`, `audio_file_location`) VALUES
(1, '0', 'Best special gift ever received or gave someone.', 'The special gift was a letter from my grandparents. It\'s not so much the letter itself as words of wisdom from my grandparents. They listed the kind of the predicament I am going to face in the following twenty years. It was written in cursive writing of course and looks tattered. It\'s like the prophecy of my life in the next two decades, totally looks like the clay tablet in The Richest Man in Babylon. Since it was too invaluable, I used to put it in the safe, and now I\'m handling it to my kid-kind of reminding them the gestures from their great grandparents and would like them to pass on to their kids and so on.', '', ''),
(2, 'Food_and_Dining', 'Food and Dining', 'Indulging in culinary delights is a sensory journey. From savoring aromatic dishes to relishing exquisite flavors, food is a universal language that transcends borders. Whether it\'s a cozy family dinner or a gourmet adventure, the art of dining brings people together. Every meal tells a story, weaving memories with the tapestry of tastes. The symphony of laughter and clinking utensils resonates, creating a shared experience. So, embark on a gastronomic exploration, where each bite is a celebration, and every shared table is a communion of cultures and companionship.', '沉浸在美食的愉悅中，是一場感官之旅。從品嚐芳香美味的菜餚到享受精緻風味，飲食是一種超越國界的共通語言。無論是溫馨的家庭晚餐還是美食探險，用餐的藝術將人們凝聚在一起。每一餐都講述一個故事，用味覺編織出記憶的線條。歡笑聲和叮噹的餐具聲構成共同體驗的交響樂章。因此，踏上美食探險，每一口都是慶典，每一張共享的餐桌都是文化和友誼的交融。', ''),
(3, 'School_and_Studying', 'School and Studying', 'Studying at school is an essential part of our educational journey. The classroom becomes a dynamic environment where students engage with various subjects, unlocking the doors to knowledge. Teachers play a pivotal role, guiding us through lessons and inspiring intellectual curiosity. In this scholastic realm, friendships flourish as we collaborate on projects and share the joys of learning. The school library becomes a treasure trove of wisdom, offering a quiet sanctuary for exploration. Exams challenge our understanding, pushing us to strive for excellence. Beyond academics, school fosters personal growth, teaching valuable life skills and nurturing a sense of responsibility. With every lesson absorbed, we pave the way for a brighter future, empowered by the gift of education.', '', ''),
(4, 'Sports_and_Outdoor_Activities', 'Sports & Outdoor Activities', 'Engaging in sports and outdoor activities is a celebration of vitality and camaraderie. Whether it\'s the thrill of scoring a goal, the rhythmic pounding of sneakers on a trail, or the splash of water in aquatic pursuits, each moment is an adventure. Team sports foster collaboration, teaching valuable lessons in teamwork and discipline. Outdoor activities provide a respite from the daily grind, connecting us with nature\'s wonders. Whether cycling through scenic landscapes or conquering a challenging hiking trail, the outdoors becomes a playground for both physical and mental well-being. Sports and outdoor pursuits not only keep our bodies fit but also nurture the spirit of competition, resilience, and the joy of embracing the great outdoors.', '參與運動和戶外活動是對活力和友誼的慶祝。無論是得分的刺激，步道上運動鞋的有節奏的敲擊，還是水上活動中的濺水聲，每一刻都是一次冒險。團隊運動促進合作，教導團隊協作和紀律的寶貴經驗。戶外活動讓我們暫時擺脫日常瑣事，與大自然的奇蹟連結在一起。無論是在風景優美的地方騎腳踏車還是征服具有挑戰性的遠足徑，戶外成為身心健康的遊樂場。運動和戶外活動不僅使我們的身體保持健康，還培養了競爭心態、韌性和擁抱大自然的喜悅。', ''),
(5, 'Special_Occasions', 'Special Occasions', 'Special occasions weave the fabric of cherished memories, a tapestry adorned with laughter, love, and shared joy. Whether it\'s a birthday, wedding, or festive holiday, these moments stand as beacons of celebration. The air is filled with anticipation, and hearts beat in rhythm with the occasion\'s significance. From the glow of candles on a cake to the echo of cheers in a crowded room, each detail contributes to the magic. Special occasions unite families and friends, fostering bonds that withstand the test of time. They are the chapters in the story of our lives, etched with gratitude and the warmth of shared experiences. In these moments, we pause to celebrate the extraordinary, savoring the beauty of togetherness and the magic that makes each occasion truly special.', '特殊場合編織了珍貴記憶的布匹，是一幅飾有笑聲、愛意和共享歡樂的繡品。無論是生日、婚禮還是慶祝節日，這些時刻都是慶典的指引燈。空氣中充滿期待，心跳與場合的重要性同步。從蛋糕上蠟燭的光芒到擁擠房間中歡呼聲的回響，每個細節都為這場魔法貢獻。特殊場合團結了家庭和朋友，培養了經得起時間考驗的情誼。它們是我們生活故事中的章節，刻滿了感激和共同經歷的溫暖。在這些時刻中，我們停下來慶祝非凡之處，品味著共同體的美好和每個特殊場合真正特別的魔力。', ''),
(6, 'Traveling', 'Traveling', 'Traveling is a passport to adventure, a journey that unfolds stories of exploration and self-discovery. Each destination offers a unique tapestry of culture, history, and breathtaking landscapes. The rhythmic hum of bustling markets, the aroma of exotic cuisines, and the friendly faces encountered along the way create a symphony of experiences. From the towering skyscrapers of urban jungles to the serene vistas of natural wonders, every step is a revelation. Traveling transcends boundaries, connecting us to the world\'s wonders and broadening our perspectives. It\'s not just about reaching a destination but immersing ourselves in the tapestry of humanity. With every adventure, we collect moments, not just souvenirs, and carve a map of memories that enrich the essence of our journey through life.', '旅行是冒險的護照，一場展開探險和自我發現故事的旅程。每個目的地都呈現出獨特的文化、歷史和令人嘆為觀止的風景。繁忙市場的韻律嗡嗡聲，異國美食的香氣，以及沿途遇到的友善面孔共同組成了一場豐富的體驗交響曲。從城市叢林的高聳摩天大樓到大自然奇觀的寧靜風景，每一步都是一次啟示。旅行超越了界限，將我們與世界奇蹟聯繫在一起，擴大我們的視野。這不僅僅是抵達目的地，更是深入融入人類的織錦。在每次冒險中，我們收集的不僅僅是紀念品，還有刻劃豐富我們人生旅程精髓的回憶地圖。', ''),
(7, 'Shopping', 'Shopping', 'Shopping is more than a transaction; it\'s an exploration of desires and a canvas for personal expression. The bustling malls and boutique-lined streets beckon with a myriad of choices, each item telling a unique story. From the thrill of discovering a hidden gem to the satisfaction of finding the perfect fit, shopping is a sensory journey. It\'s not just about acquiring possessions but curating a lifestyle. The vibrant colors, textures, and styles on display reflect the ever-changing tapestry of fashion. Beyond material indulgence, shopping becomes a social affair, a shared experience with friends or a solo adventure of self-discovery. In each purchase, we invest not just in products but in the moments that shape our identity and style.', '購物不僅僅是一筆交易；它是對慾望的探索，也是個人表達的畫布。熙攘的商場和精品店鋪滿的街道呼喚著無數選擇，每件物品都講述著獨特的故事。從發現隱藏寶石的興奮到找到完美合身的滿足感，購物是一場感官之旅。這不僅僅是獲得物品，更是營造一種生活方式。陳列的豐富色彩、質地和風格反映了時尚不斷變化的織錦。超越物質享受，購物成為社交的一環，與朋友共享的體驗，或者是個人的自我發現冒險。在每次購買中，我們投資的不僅僅是產品，還有塑造我們身份和風格的時刻。', ''),
(8, 'School_and_Studying', 'School and Studying', 'Learning is a lifelong adventure, an odyssey of discovery that knows no bounds. In the classroom, minds come alive, absorbing the wisdom shared by dedicated educators. Textbooks become gateways to new worlds, unveiling the secrets of science, history, and literature. Challenges, like puzzles waiting to be solved, shape our intellect and fortify our resilience. Beyond exams and grades, the true essence of learning lies in the acquisition of skills, the cultivation of curiosity, and the development of a growth mindset. Each lesson is a stepping stone, propelling us forward on the path of self-improvement. Embracing the joy of learning, we unlock the doors to a future rich with possibilities.', '', '');

-- --------------------------------------------------------

--
-- 資料表結構 `user`
--

CREATE TABLE `user` (
  `uID` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `uIcon` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `user`
--

INSERT INTO `user` (`uID`, `email`, `password`, `uIcon`) VALUES
('cc', 'charicewang2222@gmail.com', '0000', 'dog.jpg'),
('charice', 'charicewang2222@gmail.com', '0000', ''),
('sid01', 'charicewang3333@gmail.com', '0000', 'dog.jpg'),
('sid02', 'charicewang2222@gmail.com', '0000', 'defauit_icon.jpg'),
('sid03', 'charicewang2222@gmail.com', '0000', 'defauit_icon2.jpg'),
('sid04', 'charicewang2222@gmail.com', '0000', 'dog.jpg'),
('sid05', 'charicewang2222@gmail.com', '0000', '');

-- --------------------------------------------------------

--
-- 資料表結構 `user_score`
--

CREATE TABLE `user_score` (
  `scoreid` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `scoretype` varchar(100) NOT NULL,
  `averageAccuracyScore` float NOT NULL,
  `averagepronunciationScore` float NOT NULL,
  `averagecompletenessScore` float NOT NULL,
  `averagefluencyScore` float NOT NULL,
  `date_time` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `user_score`
--

INSERT INTO `user_score` (`scoreid`, `username`, `scoretype`, `averageAccuracyScore`, `averagepronunciationScore`, `averagecompletenessScore`, `averagefluencyScore`, `date_time`) VALUES
(1, 'ha', '', 0, 0, 0, 0, '2023-11-22 00:45:55.000000'),
(2, 'ha', '', 0, 0, 0, 0, '2023-11-22 00:49:47.000000'),
(3, 'ha', '', 0, 0, 0, 0, '2023-11-22 00:51:02.000000'),
(4, 'ha', '', 0, 0, 0, 0, '2023-11-22 01:02:58.000000'),
(5, 'sid01', '', 93, 93, 91, 99, '2023-11-22 01:19:05.000000'),
(6, 'sid01', '', 90, 87, 82, 99, '2023-11-22 01:25:20.000000'),
(7, 'sid01', 'School_and_Studying', 95, 96.8, 100, 99, '2023-11-22 01:40:28.000000'),
(8, 'sid01', 'School_and_Studying', 95, 80, 100, 99, '2023-11-22 01:42:28.000000'),
(9, 'sid01', 'Traveling', 77, 75, 69, 91, '2023-11-22 22:48:06.000000'),
(10, 'charice', 'School_and_Studying', 68, 64.2, 56, 85, '2023-11-22 22:52:06.000000'),
(11, 'cc', 'School_and_Studying', 97, 98.2, 100, 100, '2023-11-23 00:20:03.000000'),
(12, 'charice', 'School_and_Studying', 93, 95.6, 100, 99, '2023-11-23 00:25:27.000000'),
(13, 'charice', 'School_and_Studying', 77, 82.2, 82, 98, '2023-11-23 00:26:03.000000'),
(14, 'cc', 'School_and_Studying', 94, 96.4, 100, 100, '2023-11-23 18:58:38.000000'),
(15, 'cc', 'School_and_Studying', 91, 88, 91, 86, '2023-11-23 18:59:34.000000'),
(16, 'cc', 'School_and_Studying', 90, 90.8, 91, 93, '2023-11-23 19:00:04.000000'),
(17, 'cc', 'School_and_Studying', 81, 75.4, 73, 77, '2023-11-23 19:03:37.000000'),
(18, 'cc', 'School_and_Studying', 48, 53.7, 41, 97.5, '2023-11-23 19:08:28.000000'),
(19, 'cc', 'School_and_Studying', 48, 53.7, 41, 97.5, '2023-11-23 19:08:28.000000'),
(20, 'cc', 'School_and_Studying', 94, 94.8, 96, 96, '2023-11-23 19:09:45.000000'),
(21, 'cc', 'School_and_Studying', 93, 95.6, 100, 99, '2023-11-23 19:10:44.000000'),
(22, 'cc', 'Sports_and_Outdoor_Activities', 62, 59.4, 46, 97, '2023-11-23 19:28:55.000000'),
(23, 'cc', 'Sports_and_Outdoor_Activities', 71, 61.6, 46, 99, '2023-11-23 19:46:36.000000'),
(24, 'charice', 'School_and_Studying', 94, 95.8, 100, 97, '2023-11-23 19:54:28.000000'),
(25, 'charice', 'School_and_Studying', 69, 71.6, 64, 97, '2023-11-23 19:54:55.000000'),
(26, 'cc', 'Food_and_Dining', 74, 79.2, 75, 99, '2023-11-24 00:54:27.000000'),
(27, 'cc', 'Food_and_Dining', 80.7, 79.6, 75.7, 90.3, '2023-11-24 00:59:21.000000'),
(28, 'cc', 'Food_and_Dining', 80.7, 79.6, 75.7, 90.3, '2023-11-24 00:59:21.000000'),
(29, 'sid01', 'School_and_Studying', 72.5, 73.4, 69, 87.5, '2023-11-24 16:16:30.000000'),
(30, 'sid01', 'School_and_Studying', 67, 63, 54, 86, '2023-11-24 16:27:05.000000'),
(31, 'sid01', 'School_and_Studying', 81, 82.4, 79, 94, '2023-11-24 16:36:49.000000'),
(32, 'sid01', 'School_and_Studying', 100, 94, 100, 90, '2023-11-24 16:38:01.000000'),
(33, 'sid01', 'School_and_Studying', 52, 45.8, 44.5, 47.5, '2023-11-24 16:43:45.000000'),
(34, 'sid01', 'School_and_Studying', 66, 61.3, 51.3, 86.7, '2023-11-24 16:55:43.000000'),
(35, 'sid01', 'School_and_Studying', 66, 61.3, 51.3, 86.7, '2023-11-24 16:55:43.000000'),
(36, 'sid01', 'School_and_Studying', 66, 61.3, 51.3, 86.7, '2023-11-24 16:55:43.000000'),
(37, 'sid01', 'School_and_Studying', 94, 94.6, 96, 95, '2023-11-25 10:23:59.000000'),
(38, 'sid01', 'School_and_Studying', 79, 74.2, 72, 76, '2023-11-25 10:37:32.000000'),
(39, 'sid01', 'School_and_Studying', 84, 84, 82, 90, '2023-11-25 10:38:25.000000'),
(40, 'sid01', 'School_and_Studying', 97, 96.4, 100, 95, '2023-11-25 10:39:01.000000'),
(41, 'sid01', 'School_and_Studying', 93, 94.6, 96, 98, '2023-11-25 10:39:43.000000'),
(42, 'sid01', 'School_and_Studying', 95, 94, 93, 96, '2023-11-25 10:41:10.000000'),
(43, 'sid01', 'School_and_Studying', 98, 96.4, 96, 96, '2023-11-25 10:44:21.000000'),
(44, 'sid01', 'School_and_Studying', 88, 86.9, 83.5, 96, '2023-11-25 11:28:32.000000'),
(45, 'sid01', 'School_and_Studying', 88, 86.9, 83.5, 96, '2023-11-25 11:28:32.000000'),
(46, 'sid01', 'Sports_and_Outdoor_Activities', 84.5, 83.4, 79.5, 94, '2023-11-25 11:31:16.000000'),
(47, 'sid01', 'School_and_Studying', 47, 54.1, 44.5, 93, '2023-11-25 11:32:08.000000'),
(48, 'sid01', 'School_and_Studying', 47, 54.1, 44.5, 93, '2023-11-25 11:32:08.000000'),
(49, 'sid01', 'School_and_Studying', 92, 90.2, 89, 92, '2023-11-25 11:32:43.000000'),
(50, 'sid01', 'School_and_Studying', 78.5, 76.4, 81.5, 74, '2023-11-25 11:33:49.000000'),
(51, 'sid01', 'School_and_Studying', 74.7, 68.6, 58, 94.3, '2023-11-25 11:34:52.000000'),
(52, 'sid01', 'School_and_Studying', 74.7, 68.6, 58, 94.3, '2023-11-25 11:34:52.000000'),
(53, 'sid01', 'School_and_Studying', 74.7, 68.6, 58, 94.3, '2023-11-25 11:34:52.000000'),
(54, 'sid01', 'School_and_Studying', 85, 87.4, 86, 96, '2023-11-25 11:36:07.000000'),
(55, 'sid01', 'School_and_Studying', 96, 93, 96, 91, '2023-11-25 11:38:18.000000'),
(56, 'sid01', 'Food_and_Dining', 84, 81.2, 76, 94, '2023-11-25 11:39:38.000000'),
(57, 'sid01', 'Food_and_Dining', 84, 84.7, 85.5, 92, '2023-11-25 11:40:37.000000'),
(58, 'sid01', 'Food_and_Dining', 84, 84.7, 85.5, 92, '2023-11-25 11:40:37.000000');

-- --------------------------------------------------------

--
-- 資料表結構 `vocabularyfix`
--

CREATE TABLE `vocabularyfix` (
  `Vid` int(11) NOT NULL,
  `vtype` varchar(200) NOT NULL,
  `vocabulary` varchar(200) NOT NULL,
  `Example_sentences` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `vocabularyfix`
--

INSERT INTO `vocabularyfix` (`Vid`, `vtype`, `vocabulary`, `Example_sentences`) VALUES
(1, 'A', 'abandon (v.)離棄；放棄', 'The abandoned house stood alone in the woods.'),
(2, 'A', 'abiding (adj.)持久的；永久的', 'Their friendship was based on mutual respect, creating a lasting and abiding bond.'),
(3, 'A', 'ability (n.)能力；才能', 'Her artistic ability allowed her to express complex emotions through her paintings.'),
(4, 'A', 'ablaze (adj.)猛烈燃燒的；烈火熊熊的', 'The entire building was ablaze, and firefighters worked tirelessly to control the flames.'),
(5, 'A', 'abbreviate (n.)縮寫；簡稱', 'In scientific writing, it is common to abbreviate long chemical names for convenience.'),
(6, 'A', 'aberration (n.) 偏離正常或預期的行為', 'His erratic behavior was considered an aberration from his usual calm demeanor.'),
(7, 'A', 'abhorrence (n.) 厭惡的感覺；厭惡', 'The sight of cruelty filled her with a deep sense of abhorrence.'),
(8, 'A', 'abject (adj.) 極壞、不愉快或有辱人的', 'After the defeat, the team experienced an abject sense of failure.'),
(9, 'A', 'abjure (v.) 正式拒絕或放棄；戒絕', 'He decided to abjure his former unhealthy habits for a healthier lifestyle.'),
(10, 'A', 'abnormal (adj.) 偏離正常的', 'The test results showed an abnormal level of activity in the patient\'s brain.'),
(11, 'A', 'abound (v.) 大量存在；豐富', 'In the tropical rainforest, diverse species of plants and animals abound.'),
(12, 'A', 'abrasive (adj.) 由摩擦造成損害的；粗糙或刺激的', 'The abrasive surface of the sandpaper smoothed the rough edges of the wood.'),
(13, 'A', 'abrupt (adj.) 突然和意外的', 'The car came to an abrupt stop, surprising everyone inside.'),
(14, 'A', 'absolve (v.) 宣告免除罪行', 'After sincere remorse, the judge decided to absolve the defendant of guilt.'),
(15, 'A', 'absorb (v.) 吸收或吸引；理解', 'Reading helps absorb new information and broaden one\'s understanding.'),
(16, 'B', 'banish (v.) 驅逐；放逐', 'The disruptive student was banished from the classroom to maintain a peaceful learning environment.'),
(17, 'B', 'barren (adj.) 貧瘠的；不孕的', 'The barren landscape had little vegetation, making it a challenging place for survival.'),
(18, 'B', 'beacon (n.) 煙火；信號燈', 'The lighthouse served as a beacon, guiding ships safely through the dark and stormy nights.'),
(19, 'B', 'befall (v.) 發生；降臨', 'No one could predict the tragedy that would befall the small town.'),
(20, 'B', 'benevolent (adj.) 善心的；慈善的', 'The benevolent donor contributed to various charitable causes to help those in need.'),
(21, 'B', 'blatant (adj.) 公然的；明顯的', 'The politician\'s blatant disregard for the truth raised concerns among the voters.'),
(22, 'B', 'bolster (v.) 支持；加強', 'The new evidence helped bolster the case against the accused.'),
(23, 'B', 'brevity (n.) 簡潔；簡練', 'The journalist preferred brevity in his writing, conveying the essential information concisely.'),
(24, 'B', 'brisk (adj.) 輕快的；活潑的', 'The brisk morning air invigorated the joggers as they ran through the park.'),
(25, 'B', 'bucolic (adj.) 鄉村的；田園風光的', 'The painting captured the bucolic beauty of the countryside, with rolling hills and peaceful meadows.'),
(26, 'B', 'bureaucracy (n.) 官僚體系；官僚主義', 'The bureaucracy\'s complex procedures often led to delays and inefficiencies in government operations.'),
(27, 'B', 'buttress (v.) 支持；加強', 'The additional data served to buttress the scientist\'s argument, providing stronger evidence.'),
(28, 'B', 'blithe (adj.) 快樂的；無憂無慮的', 'Her blithe spirit and cheerful demeanor brightened the mood of everyone around her.'),
(29, 'B', 'bountiful (adj.) 慷慨的；豐富的', 'The farmers harvested a bountiful crop, providing an abundance of fresh produce to the community.'),
(30, 'B', 'burgeon (v.) 急速發展；迅速生長', 'The city began to burgeon with new businesses and cultural opportunities.'),
(31, 'C', 'cacophony (n.) 刺耳的噪音', 'The construction site was filled with the cacophony of drilling, hammering, and heavy machinery.'),
(32, 'C', 'cajole (v.) 哄騙；誘騙', 'She tried to cajole her friend into joining the adventurous road trip with promises of excitement and fun.'),
(33, 'C', 'calibrate (v.) 校準；校正', 'It\'s important to calibrate the equipment regularly to ensure accurate measurements.'),
(34, 'C', 'candid (adj.) 坦率的；率直的', 'His candid response revealed the honesty and transparency of his character.'),
(35, 'C', 'capitulate (v.) 投降；屈服', 'Faced with overwhelming pressure, the leader decided to capitulate and accept the terms of surrender.'),
(36, 'C', 'captivate (v.) 迷住；吸引', 'The enchanting melody captivated the audience, leaving them in awe of the talented musician.'),
(37, 'C', 'cautious (adj.) 謹慎的；小心的', 'Being cautious in unfamiliar surroundings is essential for personal safety.'),
(38, 'C', 'celestial (adj.) 天空的；天上的', 'The telescope allowed us to observe celestial bodies such as stars, planets, and galaxies.'),
(39, 'C', 'censure (v.) 譴責；非難', 'The committee decided to censure the member for violating the organization\'s code of conduct.'),
(40, 'C', 'chaotic (adj.) 混亂的；無秩序的', 'The aftermath of the earthquake was chaotic, with buildings collapsed and people in distress.'),
(41, 'C', 'cherish (v.) 珍惜；懷有激情', 'They cherish the memories of their travels, recalling the adventures and experiences they shared.'),
(42, 'C', 'circumvent (v.) 迴避；規避', 'The clever detective managed to circumvent the obstacles and solve the seemingly unsolvable case.'),
(43, 'C', 'clandestine (adj.) 秘密的；暗中的', 'The clandestine meeting took place in a secluded location, away from prying eyes.'),
(44, 'C', 'coalesce (v.) 聯合；合併', 'The two companies decided to coalesce their resources to create a stronger and more competitive entity.'),
(45, 'C', 'cogent (adj.) 有說服力的；令人信服的', 'The speaker presented a cogent argument, persuading the audience to reconsider their views.'),
(46, 'D', 'dawdle (v.) 閒晃；拖拖拉拉', 'Stop dawdling and finish your homework; you\'re wasting too much time.'),
(47, 'D', 'dearth (n.) 缺乏；不足', 'A dearth of rain in the region led to water shortages and crop failures.'),
(48, 'D', 'debilitate (v.) 使衰弱；削弱', 'The prolonged illness debilitated his strength, requiring a slow recovery process.'),
(49, 'D', 'decipher (v.) 解讀；破譯', 'The archaeologist worked tirelessly to decipher the ancient hieroglyphs on the stone tablet.'),
(50, 'D', 'deferential (adj.) 尊敬的；恭敬的', 'His deferential attitude towards elders and authority figures earned him respect in the community.'),
(51, 'D', 'deficient (adj.) 不足的；缺乏的', 'The report highlighted the deficient infrastructure in certain areas, affecting residents\' daily lives.'),
(52, 'D', 'delectable (adj.) 美味的；令人愉悅的', 'The chef prepared a delectable feast, satisfying the taste buds of all the guests.'),
(53, 'D', 'demure (adj.) 端莊的；嫻靜的', 'Her demure demeanor and polite manners made her a favorite among the guests.'),
(54, 'D', 'denounce (v.) 譴責；公然指責', 'The activist used the platform to denounce social injustice and advocate for change.'),
(55, 'D', 'deplore (v.) 強烈反對；深感遺憾', 'The community leaders deplore the rise in crime and are taking steps to address the issue.'),
(56, 'D', 'deride (v.) 嘲笑；嘲弄', 'He chose not to deride others for their mistakes but instead offered constructive feedback.'),
(57, 'D', 'desolate (adj.) 荒涼的；孤寂的', 'The abandoned village appeared desolate, with empty houses and overgrown vegetation.'),
(58, 'D', 'despondent (adj.) 沮喪的；失望的', 'After the defeat, the team felt despondent but resolved to improve in the next season.'),
(59, 'D', 'deviate (v.) 脫離；偏離', 'The river began to deviate from its usual course, causing concern among nearby residents.'),
(60, 'D', 'diligent (adj.) 勤奮的；用功的', 'Her diligent work ethic and commitment to excellence earned her the admiration of her colleagues.');

-- --------------------------------------------------------

--
-- 資料表結構 `vocabulary_question`
--

CREATE TABLE `vocabulary_question` (
  `vqID` int(11) NOT NULL,
  `vqtype` varchar(10) NOT NULL,
  `vq_description` varchar(200) NOT NULL,
  `option1` varchar(200) NOT NULL,
  `option2` varchar(200) NOT NULL,
  `option3` varchar(200) NOT NULL,
  `option4` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 傾印資料表的資料 `vocabulary_question`
--

INSERT INTO `vocabulary_question` (`vqID`, `vqtype`, `vq_description`, `option1`, `option2`, `option3`, `option4`) VALUES
(1, 'A', 'The author takes great care to maintain the _________ of the time period, incorporating accurate historical details and language.', 'abandon', 'authenticity', 'abiding', 'ability'),
(2, 'A', 'The politician was able to _________ her policy positions in a clear and concise manner.', 'ablaze', 'abbreviate', 'articulate', 'abstain'),
(3, 'A', 'She _________ for stronger environmental regulations to protect the planet.', 'absorb', 'abstain', 'advocate', 'abstract'),
(4, 'A', 'He _________ that his theory was backed by substantial evidence.', 'absurd', 'abundant', 'abyss', 'asserted'),
(5, 'A', 'The company is investing heavily in _________ to improve their customer service.', 'abate', 'aberrant', 'abode', 'Artificial intelligence'),
(6, 'B', 'The author emphasizes the importance of preserving the _________ of the story, avoiding unnecessary details that might detract from its essence.', 'banish', 'brevity', 'barren', 'beacon'),
(7, 'B', 'The speaker\'s ability to _________ humor with serious topics captivated the audience, creating an engaging and enjoyable presentation.', 'befall', 'benevolent', 'blend', 'blatant'),
(8, 'B', 'Environmentalists _________ their arguments with scientific evidence, aiming to raise awareness about the urgent need for conservation.', 'bolster', 'brevity', 'bolster', 'brisk'),
(9, 'B', 'The CEO _________ the team\'s morale by acknowledging their hard work and expressing confidence in their ability to overcome challenges.', 'bucolic', 'bureaucracy', 'buttress', 'bolstered'),
(10, 'B', 'The IT department implemented a new _________ system to ensure the security and retrieval of important data in case of unexpected incidents.', 'blatant', 'bolster', 'brevity', 'backup'),
(11, 'C', 'The author emphasizes the importance of preserving the _________ nature of the story, avoiding unnecessary details that might detract from its essence.', 'cacophony', 'comprehensive', 'cajole', 'calibrate'),
(12, 'C', 'The speaker\'s ability to _________ the audience by blending humor with serious topics created an engaging and enjoyable presentation.', 'camaraderie', 'candor', 'captivate', 'capitulate'),
(13, 'C', 'Environmentalists _________ their arguments with scientific evidence, aiming to raise awareness about the urgent need for conservation.', 'captivating', 'caustic', 'conserve', 'celestial'),
(14, 'C', 'The CEO _________ in the team\'s ability to overcome challenges bolstered their morale by acknowledging their hard work.', 'clandestine', 'concede', 'concise', 'confidence'),
(15, 'C', 'The IT department implemented a new _________ backup system to ensure the security and retrieval of important data in case of unexpected incidents.', 'condone', 'confluence', 'congenial', 'critical'),
(16, 'D', 'The _________ writer spent hours perfecting each sentence, ensuring the quality and precision of the manuscript. ', 'dawdle', 'diligent', 'debilitate', 'debunk'),
(17, 'D', 'The team _________ was evident during the brainstorming session, as members collaborated seamlessly to generate innovative ideas. ', 'decisive', 'decorum', 'dynamic', 'defer'),
(18, 'D', 'The _________ activists tirelessly campaigned for social justice, inspiring others to join their cause.', 'defraud', 'deft', 'determined', 'degrade'),
(19, 'D', 'In the face of adversity, the leader\'s _________ and quick thinking guided the team to overcome challenges and achieve success.', 'delineate', 'deluge', 'delve', 'decisiveness'),
(20, 'D', 'The company adopted a _________ approach, relying on analytics to make informed decisions and drive business growth.', 'demise', 'demure', 'deploy', 'data-driven');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `optiontext`
--
ALTER TABLE `optiontext`
  ADD PRIMARY KEY (`oID`);

--
-- 資料表索引 `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`qID`);

--
-- 資料表索引 `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uID`);

--
-- 資料表索引 `user_score`
--
ALTER TABLE `user_score`
  ADD PRIMARY KEY (`scoreid`);

--
-- 資料表索引 `vocabularyfix`
--
ALTER TABLE `vocabularyfix`
  ADD PRIMARY KEY (`Vid`);

--
-- 資料表索引 `vocabulary_question`
--
ALTER TABLE `vocabulary_question`
  ADD PRIMARY KEY (`vqID`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `optiontext`
--
ALTER TABLE `optiontext`
  MODIFY `oID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `question`
--
ALTER TABLE `question`
  MODIFY `qID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `user_score`
--
ALTER TABLE `user_score`
  MODIFY `scoreid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `vocabularyfix`
--
ALTER TABLE `vocabularyfix`
  MODIFY `Vid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `vocabulary_question`
--
ALTER TABLE `vocabulary_question`
  MODIFY `vqID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

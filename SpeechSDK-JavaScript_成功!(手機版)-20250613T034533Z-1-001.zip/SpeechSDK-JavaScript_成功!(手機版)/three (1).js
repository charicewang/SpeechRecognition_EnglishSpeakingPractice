
$(document).ready(function () {
    //初始狀態隱藏
    $(".nav-container").hide();

    $(".openbtn9").click(function () {
        //按下顯示
        $(".nav-container").toggle();
        $(this).toggleClass('active1');
    });
});

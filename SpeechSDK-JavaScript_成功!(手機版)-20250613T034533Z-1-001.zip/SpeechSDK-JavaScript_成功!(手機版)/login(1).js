$(document).ready(function () {
    $("#loginButton").click(function () {
        var value1 = $("#input1").val();
        var value2 = $("#input2").val();

        // Create an object with the values
        var dataToSend = {
            action: 'send_values',
            value1: value1,
            value2: value2
        };

        $.ajax({
            url: 'login.php',
            type: 'POST',
            data: dataToSend,
            success: function (response) {
                $("#response").html(response);
            },
            error: function (xhr, status, error) {
                console.error(error);
            }
        });
    });
});

function ck() {
    alert("123");
}
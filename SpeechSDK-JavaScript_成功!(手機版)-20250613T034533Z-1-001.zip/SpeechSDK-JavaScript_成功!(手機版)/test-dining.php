<?php
session_start();  //很重要，可以用的變數存在session裡
/*$user_id = $_SESSION["id"];*/
$user_icon = $_SESSION["icon"];
$user_name = $_SESSION["name"];
/*$user_intro = $_SESSION["intro"];
$user_occu = $_SESSION["occu"];*/

mb_internal_encoding("UTF-8");

//要的$phpVariable = $_GET['phpVariable'];
//output: Dog
//連結資料庫
$link = new PDO("mysql:dbname=EnglishSpeakingTrainingApp;host=localhost","root","0000");
//dining
//$result = $link->query("select * from question where qtype = 'dining';");
//可以這樣寫
//$result = $link->query("select * from question where qtype = $phpVariable;");

/*$i = 0;
while($row=$result->fetch()){
   $arr_text_content_dining[$i] = $row['text_content'];   
   ++$i;
   }*/
?>

<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <title>Speaking practice</title>
    <link rel="stylesheet" type="text/css" href="header.css">
    <link rel="stylesheet" type="text/css"
        href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
    <link rel="stylesheet" type="text/css"
        href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-2-9/css/5-2-9.css">
    <link href="record2.css" rel="stylesheet">
    <script src="microsoft.cognitiveservices.speech.sdk.bundle.js"></script>
    <script src="test9.js"></script>
</head>

<script>var a = 1;</script>
<style>
    footer {
        background-color: gainsboro;
        margin: 0px;
        padding: 1%;
        text-align: center;
    }
    /* 定義三欄佈局的容器 */
    .container {
        display: flex;
        height:100%;
    }


    /*成績顯示*/
    .info {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        max-height:300px;
    }

    .score-text {
        font-size: 40px;
        font-weight: bold;
    }

    .score-image-container {
        margin: 15px;
        margin-top:-40px;
        display: flex;
        width: 160px;
        height: 160px;
        position: relative;
        /*top: 50%;*/
        /*left: 30%;*/
        border-radius: 50%;
        border: 10px solid #465A93;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
        justify-content: center;
        /* 水平居中 */
        align-items: center;
        /* 垂直居中 */
        font-size: 40px;
        font-weight: bolder;
        background-color: #F0EEE2;
    }

    .score-image-container span{
        font-size:50px;
    }

    .info div p {
    text-align: center;
    font-weight: bolder;
    font-size:30px;
}


    /* 右側分栏的樣式 */
    .right-column {
        flex: 2;
        width: 60%;
        /*max-width: 400px;*/
        padding: 20px;
        background-color: #E8E7E7;
        position: relative;
        /* 讓按鈕定位於此 */
        min-height: 600px;
        max-height: 1500px;

    }

    /* 聊天室對話框的樣式 */
    .chat-box {
        margin-top: 60px;
        max-width: 100%;
        min-height: 300px;
        max-height: 1050px;
        /*height: 200px;*/
        overflow-y: auto;
        border: 1px solid #ccc;
        padding: 10px;
        background-color: #fff;
        border-radius: 20px;
        /* 設定圓角背景框 */
    }

    .chat-box-score {
        margin-top: 10px;
        max-width: 100%;
        min-height: 300px;
        max-height: 900px;
        /*height: 200px;*/
        overflow-y: auto;
        border: 1px solid #ccc;
        padding: 10px;
        background-color: #F0EEE2;
        border-radius: 10px;
        /* 設定圓角背景框 */
    }

    .chat-container {
        display: flex;
        flex-direction: column;
        position: relative;
        text-align: left;
        font-size: 20px;
        min-height: 900px;
    }

    hr {
        position: static;
    }


    .question-button {
        padding: 15px 15px;
        border-radius: 25px;
        width: 90%;
        text-align: left;
        font-size: 20px;
        background-color: #fff;
        border: 1px solid #ccc;
        margin-bottom: 20px;
        cursor: pointer;
    }

    .record-button-container {
        display: flex;
        justify-content: center;
        margin-bottom: 0px;
        margin-top: 20px;
        background-color: #CCEBF3;
    }

    .record-button-container div {
        position: absolute;
    }

    #recordButton {
        background-color: #CCEBF3;
        position: relative;
        margin-top:50px;
        left: 50%;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        background-image: url(mic.png);
        background-size: cover;
        border: none;
        cursor: pointer;
        transform: translateX(-50%);
        display: flex;
        align-items: center;
        justify-content: center;
    }

    #listen-button{
        background-color: #CCEBF3;
        /*以下都要改*/
        position: relative;
        top: 10%;
        margin-left:20px;
        /* 調整按鈕與底部的距離 */
        width: 30px;
        height: 30px;
        border-radius: 50%;
        /* 將按鈕變成圓形，border-radius 設為寬度的一半 */
        background-image: url('speaker.png');
        /* 設置按鈕的背景圖片 */
        background-size: cover;
        border: none;
        cursor: pointer;
    }


    #scoreButton {
        position: absolute;
        background-color: #465A93;
        color: white;
        border-radius: 12%;
        bottom: -30%;
        left: 30%;
        width: 200px;
        height: 60px;
        background-size: cover;
        border: none;
        cursor: pointer;
        transform: translateX(-50%);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size:30px;
    }

    #restartButton {
        position: absolute;
        background-color: #465A93;
        color: white;
        border-radius: 12%;
        bottom: -30%;
        left: 70%;
        width: 200px;
        height: 60px;
        /*border-radius: 30%;*/
        background-size: cover;
        border: none;
        cursor: pointer;
        transform: translateX(-50%);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size:30px;
    }

    /* 按鈕樣式 */
    .guide-button {
        padding: 15px 15px;
        width: 100%;
        text-align: left;
        font-size: 20px;
        background-color: #465A93;
        color: #fff;
        border: 1px solid #465A93;
        cursor: pointer;
    }

    .guide-button:hover {
        background-color: #8C52FF;
    }

    .guide-container {
        position: absolute;
        width: 100%;
        left: 0%;
        top: 40%;
    }

    .info div p {
        text-align: center;
        font-weight: bolder;
    } 

    .speaking-text {
        color: blue;
    }

    .speaking-text-wrong {
        color: red;
        cursor: pointer; /* 鼠标指针显示为手型，表示可以点击 */
    }

    .notice {
        text-align:left;
        font-size:40px;
    }

    .advise{
        margin:20px;
        font-size:30px;
    }

    .speech_logo {
        font-size: 50px;
        font-weight: bold;
        text-align:center;
        /*position: absolute;
        right:5%;*/

        /*color: orange;*/
    }

    .Question-num{
        font-size:60px;
    }

    .drop {
        position: relative;
        left: 10%;
        display: block;
        width: 80%;
        margin: 0 0 10px;

        &:hover {
            .dropOption {
                display: block;
            }
        }

        &:hover {
            .dropdown {
                display: block;
            }
        }

        &:hover {
            .dropdown.close {
                display: none;
            }
        }

        .dropOption {
            position: relative;
            margin-top:100px;
            width: 100%;
            color: #666;
            font-size: 60px;
            background-color: #fff;
            padding: 10px;
            border: 1px solid #888;
            border-radius: 5px;
            box-sizing: border-box;
            cursor: pointer;

            &::after {
                content: "";
                position: absolute;
                top: 20px;
                right: 12px;
                border-width: 8px 6px;
                border-style: solid;
                border-color: #999 transparent transparent transparent;
            }
        }

        .dropdown {
            display: none;
            width: 100%;
            max-height: 900px;
            position: absolute;
            color: #333;
            padding: 0;
            margin: 0;
            background-color: #f9f9f9;
            box-shadow: 0px 2px 3px 0px #ccc;
            border-radius: 6px;
            box-sizing: border-box;
            overflow: auto;
            z-index: 10;

            >li {
                display: block;
                color: #000;
                padding: 12px;
                font-size: 60px;
                margin: 0 10px;
                cursor: pointer;

                &:first-child {
                    margin: 10px;
                }

                &:last-child {
                    margin-bottom: 10px;
                }

                &:hover {
                    background-color: #465A93;
                    color: white;
                    border-radius: 6px;
                }
            }

            &::-webkit-scrollbar {
                width: 15px;
            }

            &::-webkit-scrollbar-track {
                background-color: #eee;
                border-radius: 6px;
            }

            &::-webkit-scrollbar-thumb {
                background-color: #465A93;
                border-radius: 15px;
            }

            &::-webkit-scrollbar-button {
                background-color: #f9f9f9;
            }
        }
    }

    nav li.has-child>div {
    position: absolute;
    z-index: 9999; /* 一个较高的数值，确保它位于其他元素上方 */
    border-radius: 5%;
    right: 0;
    top: 62px;
    background: white;
    width: 200px;
    visibility: hidden;
    opacity: 0;
    transition: all .3s;
}

#content{
    font-size:40px;
}

#again_button{
    position: relative;
    background-color: #465A93;
    color: white;
    border-radius: 12%;
    left: 50%;
    bottom:-5%;
    width: 200px;
    height: 60px;
    /*border-radius: 30%;*/
    background-size: cover;
    border: none;
    cursor: pointer;
    transform: translateX(-50%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size:30px;
}

.example-sentence {
            display: none; /* 默认隐藏 */
            padding: 10px;
            border: 1px solid #ccc;
            margin-top: 10px;
            font-size: 25px;
        }

#content div button {
    font-size:40px;
    text-align:left;
}

</style>


<body>
<header id="header">
        <a href="speech_home.php" class="logo">
            <p class="speech_logo">BilingoSpeak</p>
        </a>
        <nav>
            <ul>
                <li class="has-child"><img class="icon" src="three.jpg"> <!--class="in"-->
                    <div>
                        <ul>
                            <div class="pro_icon">
                                <img src="<?php echo $user_icon; ?>">
                                <div class="info">
                                    <p><?php echo $user_name; ?></p>
                                </div>
                            </div>
                            <li class="menu"><a href="ABOUT US.html">Profile</a></li>
                            <li class="menu"><a href="speech_home.php">Home</a></li>
                            <li class="menu"><a href="#">About</a></li>
                            <li class="menu"><a href="編輯畫面.html">Practice</a></li>
                            <li class="menu"><a href="record.php">Record</a></li>
                            <li class="menu"><a href="#">setting</a></li>
                            <li class="menu"><a href="speech_home_before_login.php">LOG OUT</a></li>
                            <br>
                        </ul>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <hr class="hr-1">
    <hr class="hr-2">
    <div class="container">
        <div class="right-column" id="right-column">
            <div class="chat-box">
                <div class="Question-num">Read the text as it's written:</div>
                <hr>
                <div class="chat-container">
                    <div><br></div>
                    <div id="content"><?php /*echo $arr_text_content_dining[0];*/ ?>
                        <div><a href="#" onclick="toggleExample('example1')"> <button>A: Good evening! Have you decided on what you'd like to order?</button></a></div>
                        <div id="example1" class="example-sentence">晚上好！您決定好要點什麼了嗎？</div>
                        <div><a href="#" onclick="toggleExample('example2')"> <button>B: Hello! Not yet, I'm still browsing the menu. What do you recommend?</button></a></div>
                        <div id="example2" class="example-sentence">你好！還沒有，我還在看菜單。有什麼推薦嗎？</div>
                        <div><a href="#" onclick="toggleExample('example3')"> <button>A: Our chef's specials are quite popular. The seafood pasta is a personal favorite.</button></a></div>
                        <div id="example3" class="example-sentence">我們廚師特製的菜色很受歡迎。海鮮義大利麵是我個人的最愛。</div>
                        <div><a href="#" onclick="toggleExample('example4')"> <button>B: Sounds delicious. I'll go with the seafood pasta, please.</button></a></div>
                        <div id="example4" class="example-sentence">聽起來很美味。我就點海鮮義大利麵吧。</div>
                        <div><a href="#" onclick="toggleExample('example5')"> <button>A: Excellent choice! And for drinks?</button></a></div>
                        <div id="example5" class="example-sentence">好選擇！喝點什麼呢？</div>
                        <div><a href="#" onclick="toggleExample('example6')"> <button>B: I'll have a sparkling water, please.</button></a></div>
                        <div id="example6" class="example-sentence">我要一杯氣泡水，謝謝。</div>
                        <div><a href="#" onclick="toggleExample('example7')"> <button>A: Certainly. One seafood pasta and a sparkling water. Anything else?</button></a></div>
                        <div id="example7" class="example-sentence">好的。一份海鮮義大利麵和一杯氣泡水。還需要別的嗎？</div>
                        <div><a href="#" onclick="toggleExample('example8')"> <button>B: No, that's all for now, thank you.</button></a></div>
                        <div id="example8" class="example-sentence">不，就這些，謝謝。</div>
                    
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    B: No, that's all for now, thank you.<br>
                    </div>
                
                </div>
            </div>
            <div class="record-button-container">
                <div><button id="recordButton" onclick="main()"></button></div>
            </div>
            <button id="scoreButton">Finish</button>
            <button id="restartButton">Restart</button>
        </div>
    </div>
    <script>
    function toggleExample(id) {
        var example = document.getElementById(id);
        example.style.display = (example.style.display === 'none' || example.style.display === '') ? 'block' : 'none';
    }
</script>
</body>

</html>
<?php 
$var = 'I love you !';
?>
<a href="page02.php?new=I%20love%20you%20!">get</a>
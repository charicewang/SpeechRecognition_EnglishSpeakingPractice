<!DOCTYPE html>

<html lang="ja">
<head>
<meta charset="utf-8">
<title>Speech_Home</title>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/Modaal/0.4.4/css/modaal.min.css">
<link rel="stylesheet" type="text/css" href="">
<link rel="stylesheet" type="text/css" href="header5.css">

</head>

<style>
    body {
    font-family: 'Montserrat', sans-serif;
}

/*.place.img {
    width: 20px;
    height: 20px;
}*/

.section {
    text-align: left;
    padding-left: 5%;
}

.speech_logo {
    font-size: 40px;
}

/* 鏈接元素的樣式 */
.image-link {
    display: inline-block;
    /* 設定元素為行內區塊，使其能夠設定寬高 */
    position: relative;
}

/* 正常時的按鈕樣式 */
.image-link button {
    /*background-image: url('option_back.jpg');
    background-size: cover;
    background-repeat: no-repeat;*/
    background-color:lightblue;
    /*border-radius: 5px;
    width: 350px;
    height: 250px;*/
    border: 5px;
    color: black;
    font-size: 20px;
    /*cursor: pointer;*/
    /* 添加模糊效果 */
    transition: filter 0.3s ease;
    margin-top:10px;
    /* 添加過渡效果 */
}


/*.button-container {
    position: relative;
    display: inline-block;
}*/

.flex_container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}

#header {
    /*向上滑會固定於頂端*/
    position: -webkit-sticky;
    position: sticky;
    top: 0;
    height: 10%;
    padding: 0% 3%;
    z-index: 999;
    /*最前面*/

    /*將header內容物至於兩端*/
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: none;
    background-color: white;
    color: black;
    text-align: center;
    /*background-color:black;*/

}


.menu {
    text-align: left;
    width: 90%;
    margin: 5%;
}

.menu :hover {
    background-color: whitesmoke;
}


#big_pic h1::before {
    background: none;
}


@media only screen and (max-width: 480px) {
    .sort-btn {
        justify-content: space-between;
    }

    .sort-btn li {
        width: 48%;
        margin: 0 0 10px 0;
        text-align: center;
    }
}

@media only screen and (max-width: 768px) {
    .item {
        width: 49.5%;
    }
}

#map {
    background-color: white;
    padding: 0% 5%;
    padding-bottom: 10%;
    text-align: center;
}


.place {
    padding-top: 5%;
    width: 33%;
    height: 80%;
}

.place div {
    width: 100%;
    color: #666
}

.place img {
    width: 90%;
    vertical-align: middle;
}

.place hr {
    size: 1px;
}

.place button{
    width: 90%;
}

.place a {
    text-decoration: none;
    color: black;
}

.place img:hover,
.place p:hover {
    filter: drop-shadow(0 0 0.25rem gray);
    transition-duration: 1s;
    text-decoration: underline;
}

footer {
    background-color: gainsboro;
    margin: 0px;
    padding: 1%;
}

#cover-text{
    /*background-color:gray;*/
    background-color: rgba(128, 128, 128, 0.5);
    width:70%;
    margin-left:15%;
    margin-top:60px;
    padding: 20px;
    border-radius: 20px;
}

h1{
    color: #162845;
    font-size: 32px;
    font-weight: 500;
    text-align: center;
    font-family: 'Roboto';
    useCustomTag: false;
    line-height: 1.2;
    margin-bottom: 2%;
}

#intro-text{
    text-align: left;
    margin-left: 10%;
}

#intro-item{
    text-align: left;
    margin-left: 10%;
    margin-top: 2%;
    margin-bottom: 5%;
}

#main-img{
    width: 100%;
    height: 40vh;
    position: relative;
    color: whitesmoke;
    text-align: center;
    background: url("homepage.jpg") no-repeat center;
    background-size: cover;
}

#get-start{
    background-color:black;
    width:60%;
    border-radius: 10px;
    margin-top:20px;
    color:white;
    font-size: 38px;
    font-family: 'Roboto';
    font-weight: 700;
}

#get-start-outer{
    display: flex;
    justify-content: center; /* 水平居中 */
    align-items: center; /* 垂直居中 */
}

#new_columns-108-9772 {
    display: flex;
    justify-content: space-around;
}

/*@media (max-width: 1280px)
#div_block-109-9772 {
    flex-direction: column;
    display: flex;
}*/

#div_block-109-9772 {
    align-items: center;
    text-align: center;
    flex-direction: column;
    display: flex;
    justify-content: center;
    padding-top: 12px;
    padding-left: 12px;
    padding-right: 12px;
    padding-bottom: 12px;
    width: 33%;
}

.ct-div-block {
    display: flex;
    flex-wrap: nowrap;
    flex-direction: column;
    align-items: flex-start;
}

*, :after, :before {
    box-sizing: inherit;
}

#div_block-110-9772 {
    font-family: 'Roboto';
    font-size: 16px;
    text-align: center;
    color: #ececec;
    margin-top: 10px;
    background-color: #162845;
    flex-direction: column;
    display: flex;
    align-items: center;
    padding-bottom: 12px;
    border-radius: 5px;
}

/* 模态对话框容器 */
.modal {
        display: none;
        /* 初始隐藏 */
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7);
        /* 半透明背景 */
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1;
    }




    /* 模态对话框内容 */
    .modal-content {
        position: absolute;
        /* 使用绝对定位 */
        top: 50%;
        /* 上边距设置为50% */
        left: 50%;
        /* 左边距设置为50% */
        transform: translate(-50%, -50%);
        /* 使用transform将元素居中 */
        background-color: #f4f4f4;
        padding: 20px;
        text-align: center;
        border-radius: 10px;
        /* 将边框半径设置为正方形 */
        width: 400px;
        height: 300px;
    }

    .modal-content p {
        text-align: center;
        font-size: 20px;
    }


    .modal-content button {
        background-color: lightblue;
        border: 2px solid gray;
        left: 0%;
        padding: 3px;
        /*border: 5px;*/
        margin: 10px;
        color: black;
        font-size: 20px;
        cursor: pointer;
        transition: filter 0.3s ease;
        border-radius: 5px;
    }

    .modal-content button:hover {
        background-color: rgb(147, 189, 240);
    }

    .modal-content-before {
        position: absolute;
        /* 使用绝对定位 */
        top: 50%;
        /* 上边距设置为50% */
        left: 50%;
        /* 左边距设置为50% */
        transform: translate(-50%, -50%);
        /* 使用transform将元素居中 */
        background-color: #f4f4f4;
        padding: 20px;
        text-align: center;
        border-radius: 10px;
        /* 将边框半径设置为正方形 */
        width: 600px;
        height: 300px;
    }

    .modal-content-before p {
        text-align: center;
        font-size: 40px;
    }


    .modal-content-before button {
        background-color: lightblue;
        border: 2px solid gray;
        left: 0%;
        padding: 3px;
        /*border: 5px;*/
        margin: 40px;
        color: black;
        font-size: 40px;
        cursor: pointer;
        transition: filter 0.3s ease;
        border-radius: 5px;
    }

    .modal-content-before button:hover {
        background-color: rgb(147, 189, 240);
    }


</style>

<body>
    <!--font-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&family=Raleway:wght@200&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.0.min.js"></script>

 

    <div id="main-img">
        <header id="header">
            <a href="speech_home.php">
                <p class="speech_logo">BilingoSpeak</p>
            </a>
            <nav>
                <ul>
                    <li id="Home"><a href="http://localhost/SpeechSDK-JavaScript_%E6%88%90%E5%8A%9F!/speech_home.php">
                            <p><b>Home</b></p>
                        </a></li>
                    <li id="About"><a href="">
                            <p><b>About</b></p>
                        </a></li>
                    <li id="Logout"><a href="speech_home_before_login.php">
                            <p><b>Logout</b></p>
                        </a></li>
                </ul>
            </nav>
        </header>
        <section id="big_pic"></section>   
        <div id="cover-text">
            <section id="intro"><h1>Unlock English proficiency with Us!</h1></section>
            <section id="intro-text">Break down your English language barrier with English Path! Enhance your career, <br>build confidence, and earn certifications through our diverse English courses in stunning cities.</section>
            <section id="intro-item">⚫  practice anytime, anywhere through both the computer and mobile divice <br>⚫  share your practice achievements and provide personal feedback to other users<br>⚫  record your performance in each practice session<br>⚫  recommend practice topics based on your upcoming events</section>
        </div> 
    </div>

    

    <main>
        <div id="get-start-outer"><div id="get-start">Get Started!</div></div>
        <section id="map">            
            <div class= "flex_container">
                <div class= "place">
                        <div class="button-container">
                            <div class="image-link">
                                <img id="image-117-9772" alt="" src="speaking.jpg" class="ct-image ">
                                <h1 id="headline-128-9772" class="ct-headline">Speaking Practice</h1>
                                <div id="text_block-119-9772" class="ct-text-block">Enhance your spoken English with Speaking Practice. Practice real conversations, get instant feedback, and boost your speaking skills.</div>
                                <button><a id="link_button-120-9772" class="ct-link-button " href="score-option.php">Go now<br></a></button>
                            </div>
                        </div>      
                </div>

                <div class= "place">
                        <div class="button-container">
                            <div class="image-link">
                                <img id="image-117-9772" alt="" src="word.jpg" class="ct-image ">
                                <h1 id="headline-128-9772" class="ct-headline">Vocabulary</h1>
                                <div id="text_block-119-9772" class="ct-text-block">Improve your vocabulary with Vocabulary Practice. Expand your word bank, learn new words, and enhance your language skills. </div>
                                <button><a id="link_button-120-9772" class="ct-link-button " href="Vocabularyoption.php">Go now<br></a></button>
                            </div>
                        </div>  
                </div>

                <div class= "place">
                        <div class="button-container">
                            <div class="image-link">
                                <img id="image-117-9772" alt="" src="community.jpg" class="ct-image ">
                                <h1 id="headline-128-9772" class="ct-headline">Community</h1>
                                <div id="text_block-119-9772" class="ct-text-block">Explore diverse cultures in our welcoming community. Connect with language enthusiasts, share experiences, and learn together. </div>
                                <button><a id="link_button-120-9772" class="ct-link-button " href="record.php">Go now<br></a></button>
                            </div>
                        </div>
                </div>
            </div>
        </section>
    </main>

    <!--頁尾-->
    <footer>
        <p>@other information</p>

    </footer>

    <script type="text/javascript">
        /* exported gapiLoaded */
        /* exported gisLoaded */
        /* exported handleAuthClick */
        /* exported handleSignoutClick */

        // TODO(developer): Set to client ID and API key from the Developer Console
        const CLIENT_ID = '817455659980-ru1h2cd1d68hspvhlqhn3ao56ktva1f0.apps.googleusercontent.com';
        const API_KEY = 'AIzaSyBcSU576db8ZjVy_HVtiQiMYO_yTZILR_E';

        // Discovery doc URL for APIs used by the quickstart
        const DISCOVERY_DOC = 'https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest';

        // Authorization scopes required by the API; multiple scopes can be
        // included, separated by spaces.
        const SCOPES = 'https://www.googleapis.com/auth/calendar.readonly';

        let tokenClient;
        let gapiInited = false;
        let gisInited = false;

        document.getElementById('authorize_button').style.visibility = 'hidden';

        /*你懂的*/
        // 显示模态对话框
        function openModal() {
            var modal = document.getElementById('myModal');
            modal.style.display = 'block';
        }

        // 关闭模态对话框
        function closeModal() {
            var modal = document.getElementById('myModal');
            modal.style.display = 'none';
        }

        // 页面加载后显示模态对话框
        window.onload = function () {
            openModal();
        };


        /**
         * Callback after api.js is loaded.
         */
        function gapiLoaded() {
            gapi.load('client', initializeGapiClient);
        }

        /**
         * Callback after the API client is loaded. Loads the
         * discovery doc to initialize the API.
         */
        async function initializeGapiClient() {
            await gapi.client.init({
                apiKey: API_KEY,
                discoveryDocs: [DISCOVERY_DOC],
            });
            gapiInited = true;
            maybeEnableButtons();
        }

        /**
         * Callback after Google Identity Services are loaded.
         */
        function gisLoaded() {
            tokenClient = google.accounts.oauth2.initTokenClient({
                client_id: CLIENT_ID,
                scope: SCOPES,
                callback: '', // defined later
            });
            gisInited = true;
            maybeEnableButtons();
        }

        /**
         * Enables user interaction after all libraries are loaded.
         */
        function maybeEnableButtons() {
            if (gapiInited && gisInited) {
                document.getElementById('authorize_button').style.visibility = 'visible';
            }
        }

        /**
         *  Sign in the user upon button click.
         */
        function handleAuthClick() {
            tokenClient.callback = async (resp) => {
                if (resp.error !== undefined) {
                    throw (resp);
                }
                //document.getElementById('signout_button').style.visibility = 'visible';
                //document.getElementById('authorize_button').innerText = 'Refresh';
                await listUpcomingEvents();
            };

            if (gapi.client.getToken() === null) {
                // Prompt the user to select a Google Account and ask for consent to share their data
                // when establishing a new session.
                tokenClient.requestAccessToken({ prompt: 'consent' });
            } else {
                // Skip display of account chooser and consent dialog for an existing session.
                tokenClient.requestAccessToken({ prompt: '' });
            }
        }


        /**
         * Print the summary and start datetime/date of the next ten events in
         * the authorized user's calendar. If no events are found an
         * appropriate message is printed.
         */
        async function listUpcomingEvents() {
            let response;
            try {
                const request = {
                    'calendarId': 'primary',
                    'timeMin': (new Date()).toISOString(),
                    'showDeleted': false,
                    'singleEvents': true,
                    'maxResults': 10,
                    'orderBy': 'startTime',
                };
                response = await gapi.client.calendar.events.list(request);
            } catch (err) {
                document.getElementById('content').innerText = err.message;
                return;
            }

            const events = response.result.items;
            if (!events || events.length == 0) {
                document.getElementById('content').innerText = 'No events found.';
                return;
            }

            if (events && events.length > 0) {
                // Check if any event is related to dining
                const diningEvents = events.filter(event => event.summary.toLowerCase().includes('dining'));

                if (diningEvents.length > 0) {
                    console.log('Tomorrow, you have a dining event. Consider practicing English dialogues related to dining.');
                    //alert('Tomorrow, you have a dining event. Consider practicing English dialogues related to dining.');
                }
            }
            // 生成事件列表，包括"月/日"格式的日期和事件标题
            const eventList = events.map(event => {
                const eventDate = new Date(event.start.dateTime || event.start.date);
                const formattedDate = eventDate.toLocaleDateString(undefined, {
                    month: 'numeric', // 月份
                    day: 'numeric',   // 日期
                });
                return `You have a/an '${event.summary}' event on ${formattedDate}.`;
            });

            // 显示事件列表
            var thecontent = document.getElementById('myModal');
            thecontent.innerHTML = `  
            <div class="modal-content">                         
                <p id="p1"></p>
                <p id="p2"></p>
                <p>推薦練習主題:<br>外出用餐的英語對話</p>
                <button onclick="closeModal()">I understand</button>
            </div>     
`;
            //thecontent.innerText = eventList.join('\n') + '\nRecommended practice topics:\nEnglish conversation for dining.';
            var p1 = document.getElementById('p1');
            var p2 = document.getElementById('p2');
            p1.innerText = eventList.join('\n');
            p2.innerText = '\nRecommended practice topics:\nEnglish conversation for dining.';
            
        }

    </script>
    <script async defer src="https://apis.google.com/js/api.js" onload="gapiLoaded()"></script>
    <script async defer src="https://accounts.google.com/gsi/client" onload="gisLoaded()"></script>


    <script src="jquery-3.6.0.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <!--GALLERY-->
    <script src="https://unpkg.com/web-animations-js@2.3.2/web-animations.min.js"></script>
    <script src="https://unpkg.com/muuri@0.8.0/dist/muuri.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
    <!--SLIDE_SHOW-->
    <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

    <!--LOG IN-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Modaal/0.4.4/js/modaal.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.js"></script>
    <script src="login_motion.js"></script>

    <script src="js.js"></script>
</body>
</html>


var resultDiv = document.getElementById('result'); //顯示提示訊息，可刪除
var mediaRecorder;
var recordedChunks = [];
var isRecording = false;
var stream;
const scoreNumber = {
    accuracyScore: 0,
    fluencyScore: 0,
    compScore: 0,
};
const allWords = [];
var currentText = [];
var startOffset = 0;
var recognizedWords = [];
var fluencyScores = [];
var durations = [];
var jo = {};

SPEECH_KEY = "256fb24abbe7493c98ae35a2c37f8e71";
SPEECH_REGION = "eastus";
const referenceText = "Our focus has always been on technology, changing the look is an unnecessary cost. Almost immediately, some of our supporters changed their minds! Even my co-worker changed his mind! ";

function main() {
    //測試用的
    var recordButton = document.getElementById("recordButton");
    recordButton.addEventListener("click", function () {
        //saveRecording();
        saveScore();
    });
    //正式要用的
    /*
    var scorebutton = document.getElementById("scoreButton");

    const audioConfig = SpeechSDK.AudioConfig.fromDefaultMicrophoneInput();
    var speechConfig = SpeechSDK.SpeechConfig.fromSubscription(SPEECH_KEY, SPEECH_REGION);

    // create pronunciation assessment config
    var pronunciationAssessmentConfig = new SpeechSDK.PronunciationAssessmentConfig(
        referenceText,
        SpeechSDK.PronunciationAssessmentGradingSystem.HundredMark,
        SpeechSDK.PronunciationAssessmentGranularity.Phoneme,
        true
    );

    // setting the recognition language to English.
    speechConfig.speechRecognitionLanguage = "en-US";

    // create the speech recognizer
    var recognizer = new SpeechSDK.SpeechRecognizer(speechConfig, audioConfig);
    pronunciationAssessmentConfig.applyTo(recognizer);

    recognizer.startContinuousRecognitionAsync(); // Start continuous recognition

    recognizer.recognized = function (s, e) {
        if (e.result.reason === SpeechSDK.ResultReason.RecognizedSpeech) {
            var pronunciationResult = SpeechSDK.PronunciationAssessmentResult.fromResult(e.result);
            var pa = pronunciationResult.accuracyScore;
            var pp = pronunciationResult.pronunciationScore;
            var pc = pronunciationResult.completenessScore;
            var pf = pronunciationResult.fluencyScore;


            saveScore(pa, pp, pc, pf);
            console.log("pronunciation assessment for: ", e.result.text);
            var pronunciation_result = SpeechSDK.PronunciationAssessmentResult.fromResult(e.result);
            console.log(" Accuracy score: ", pronunciation_result.accuracyScore, '\n',
                "pronunciation score: ", pronunciation_result.pronunciationScore, '\n',
                "completeness score : ", pronunciation_result.completenessScore, '\n',
                "fluency score: ", pronunciation_result.fluencyScore,
            );

            jo = eval("(" + e.result.properties.getProperty(SpeechSDK.PropertyId.SpeechServiceResponse_JsonResult) + ")");
            const nb = jo["NBest"][0];
            startOffset = nb.Words[0].Offset;
            const localtext = _.map(nb.Words, (item) => item.Word.toLowerCase());
            currentText = currentText.concat(localtext);
            fluencyScores.push(nb.PronunciationAssessment.FluencyScore);
            const isSucceeded = jo.RecognitionStatus === 'Success';
            const nBestWords = jo.NBest[0].Words;
            const durationList = [];
            _.forEach(nBestWords, (word) => {
                recognizedWords.push(word);
                durationList.push(word.Duration);
            });
            durations.push(_.sum(durationList));

            if (isSucceeded && nBestWords) {
                allWords.push(...nBestWords);
            }
            // 檢查特定條件，如果需要中斷連續識別
            scorebutton.addEventListener("click", function () {
                saveRecording();
                stopRecognition(); // 在按鈕點擊時停止識別
            });
        }

    };*/
}

function stopRecognition() {
    if (recognizer) {
        recognizer.stopContinuousRecognitionAsync(); // 停止連續識別
    }
}

function toggleRecording() {
    isRecording = !isRecording;
    var recordButton = document.getElementById('recordButton');

    if (isRecording) {
        startRecording();
        recordButton.classList.add('active'); // 添加 active 類別，使按鈕變色並開始閃爍
        main();
    } else {
        stopRecording();
        recordButton.classList.remove('active'); // 移除 active 類別，停止閃爍
    }
}

async function startRecording() {
    try {
        recordedChunks = [];// 重置錄音數據陣列
        stream = await navigator.mediaDevices.getUserMedia({
            audio: true
        });
        mediaRecorder = new MediaRecorder(stream);

        mediaRecorder.ondataavailable = function (event) {
            if (event.data.size > 0) {
                recordedChunks.push(event.data);
            }
        };

        mediaRecorder.onstop = function () {
            isRecording = false;
            saveRecording();
        };

        mediaRecorder.start();
        isRecording = true;
    } catch (error) {
        resultDiv.textContent = '無法獲取麥克風訪問權限: ' + error.message;
    }
}

function stopRecording() {
    console.log("i m here")
    mediaRecorder.stop();
    stream.getTracks().forEach(track => track.stop());
}

function saveRecording() {
    var blob = new Blob(recordedChunks,
        {
            type: 'audio/ogg'
        });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'recorded_data.ogg';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);

    var saved = document.getElementById('result');
    saved.textContent = "錄音已完成並儲存至\"我的練習\"。";
}


//測試用的
function saveScore() {
    var scorebutton = document.getElementById("scoreButton");
    var a = 100;
    var b = 100;
    var c = 100;
    var d = 100;


    scorebutton.addEventListener("click", function () {
        var body = document.querySelector("body");
        body.innerHTML = `<header id="header">
        <a href="http://localhost/SpeechSDK-JavaScript_%E6%88%90%E5%8A%9F!/speech_home.php" class="logo">
            <p class="speech_logo">Logo</p>
        </a>
        <nav>
            <ul>
                <li id="Home"><a href="http://localhost/SpeechSDK-JavaScript_%E6%88%90%E5%8A%9F!/speech_home.php"
                        class="logo">
                        <p><b>Home</b></p>
                    </a></li>
                <li id="About"><a href="" class="logo">
                        <p><b>About</b></p>
                    </a></li>
                <li id="Logout"><a href="" class="logo">
                        <p><b>Logout</b></p>
                    </a></li>
            </ul>
        </nav>
    </header>
    <!--<div class="wall"></div>-->
    <hr class="hr-1">
    <hr class="hr-2">
    <div class="container">
        <div class="left-column">
            <div class="info">
                <!--左側區塊-->
                <div class="profile-image-container">
                    <img class="profile-image" src="boy.jpg">
                </div>
                <p class="user-name">User123's <br>Speaking practice</p>
            </div>

            <div class="guide-container">
                <div>
                    <a href="">
                        <button class="guide-button">Practice</button>
                    </a>
                </div>

                <div>
                    <a href="">
                        <button class="guide-button">History</button>
                    </a>
                </div>

                <div>
                    <a href="http://localhost/SpeechSDK-JavaScript_%E6%88%90%E5%8A%9F!/speech_home.php">
                        <button class="guide-button">Home</button>
                    </a>
                </div>

                <div>
                    <a href="">
                        <button class="guide-button">Setting</button>
                    </a>
                </div>
            </div>
        </div>
        <div class="middle-column">
        <div class="chat-box">
                <div class="Question-num">Answer</div>
                <hr>
                <div class="chat-container">
                    <div>I disagree with the idea that people should always be truthful. First of all, telling a
                        white lie is better in many situations. For example.......I disagree with the idea that
                        people should always be truthful. First of all, telling a
                        white lie is better in many situations. For example.......I disagree with the idea that
                        people should always be truthful. First of all, telling a
                        white lie is better in many situations. For example.......</div>
                </div>
            </div>
            <div class="info">
            <!--左側區塊-->
                <div class="score-text">Your Score......</div>
                <div class="score-image-container">
                    <span id="accuracyScore"></span>
                </div>
            </div>
        </div>
    </div>
`;
        /*var mcolumn = document.querySelector(".middle-column");
        var rcolumn = document.querySelector(".right-column");

        mcolumn.innerHTML = `<div class="info">
        <!--左側區塊-->
        <div class="score-text">Your Accuracy Score......</div>
        <div class="score-image-container">
            <img class="score-image" src="boy.jpg">
        </div>
    </div>`;


        // 隐藏或删除右侧对话框的内容
        rcolumn.innerHTML = `
    <div>
        <div id="accuracyScore"></div>
        <div id="pronunciationScore"></div>
        <div id="completenessScore"></div>
        <div id="fluencyScore"></div>
        <div id="detailScore"></div>
        <div id="result"></div>
    </div>
`;*/
        var accuracyScoreElement = document.getElementById('accuracyScore');
        var pronunciationScoreElement = document.getElementById('pronunciationScore');
        var completenessScoreElement = document.getElementById('completenessScore');
        var fluencyScoreElement = document.getElementById('fluencyScore');


        accuracyScoreElement.textContent = a + "%";
        pronunciationScoreElement.textContent = "Pronunciation Score: " + b;//整體分數
        completenessScoreElement.textContent = "Completeness Score: " + c;
        fluencyScoreElement.textContent = "Fluency Score: " + d;
    });
}

//正式要用的
/*function saveScore(pa, pp, pc, pf) {
    //var scorebutton = document.getElementById("scoreButton");

    scorebutton.addEventListener("click", function () {
        var rcolumn = document.querySelector(".right-column");

        // 隐藏或删除右侧对话框的内容
        rcolumn.innerHTML = `
    <div>
        <div id="accuracyScore"></div>
        <div id="pronunciationScore"></div>
        <div id="completenessScore"></div>
        <div id="fluencyScore"></div>
        <div id="detailScore"></div>
        <div id="result"></div>
    </div>
`;

        var accuracyScoreElement = document.getElementById('accuracyScore');
        var pronunciationScoreElement = document.getElementById('pronunciationScore');
        var completenessScoreElement = document.getElementById('completenessScore');
        var fluencyScoreElement = document.getElementById('fluencyScore');

        accuracyScoreElement.textContent = "Accuracy Score: " + pa;
        pronunciationScoreElement.textContent = "Pronunciation Score: " + pp;
        completenessScoreElement.textContent = "Completeness Score: " + pc;
        fluencyScoreElement.textContent = "Fluency Score: " + pf;

    });
}*/
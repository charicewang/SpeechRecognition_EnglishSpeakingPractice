<!DOCTYPE html>

<html>

<head>
	<title>Speech_Home</title>
	<link href="login_style.css" rel="stylesheet">
	<meta charset="utf-8">

</head>

<style>
	body {
		font-family: 'Montserrat', sans-serif;
		margin: 2%;
	}

	.hide {
		display: none;
	}

	.show {
		display: block;
	}

	.flex_container {
		display: flex;
		flex-wrap: wrap;
		justify-content: center;
	}


	#header {
		/*向上滑會固定於頂端*/
		top: 0;
		height: 10%;
		padding: 0% 3%;
		z-index: 999;
		/*最前面*/

		/*將header內容物至於兩端*/
		display: flex;
		justify-content: space-between;
		align-items: center;
		background: none;
		color: black;
		text-align: center;

	}

	.speech_logo {
		font-size: 40px;
		font-weight: bolder;
		color: #CCEBF3;
	}


	button {
		background-color: unset;
		border: none;
		margin: 0%;
		padding: 0%;
	}

	nav ul {
		list-style: none;
		display: flex;
		justify-content: center;
	}

	nav ul li a {
		color: black;
		padding: 10px;
	}

	/*menu botton*/

	.openbtn9 {
		position: relative;
		/*ボタン内側の基点となるためrelativeを指定*/
		background: white;
		cursor: pointer;
		width: 50px;
		height: 50px;
		border-radius: 5px;
		overflow: hidden;
		/*ジャンプしてはみ出た要素を消す*/
	}

	/*ボタン内側*/

	.openbtn9 .openbtn-area {
		transition: all .4s;
		/*アニメーションの設定*/
	}

	.openbtn9 span {
		display: inline-block;
		transition: all .4s;
		/*アニメーションの設定*/
		position: absolute;
		left: 14px;
		height: 3px;
		border-radius: 2px;
		background: gray;
		width: 45%;
	}


	.openbtn9 span:nth-of-type(1) {
		top: 15px;
	}

	.openbtn9 span:nth-of-type(2) {
		top: 23px;
	}

	.openbtn9 span:nth-of-type(3) {
		top: 31px;
	}


	/*activeクラスが付与されると .openbtn-areaが360度回転し、
その中の線のtopの位置や形状が変化して×に*/

	.openbtn9.active .openbtn-area {
		transform: rotateX(360deg);
	}

	.openbtn9.active span:nth-of-type(1) {
		top: 18px;
		left: 18px;
		transform: translateY(6px) rotate(-135deg);
		width: 30%;
	}

	.openbtn9.active span:nth-of-type(2) {
		opacity: 0;
	}

	.openbtn9.active span:nth-of-type(3) {
		top: 30px;
		left: 18px;
		transform: translateY(-6px) rotate(135deg);
		width: 30%;
	}

	/*end of menu botton*/

	/*上滑時頁面蓋過圖片*/
	#big_pic:before {
		content: "";
		position: fixed;
		top: 0;
		left: 0;
		z-index: -1;
		width: 100%;
		height: 100vh;
		/*背景圖*/
		background: url("option_back.jpg") no-repeat center;
		background-size: cover;
	}


	a {
		color: gray;
		text-decoration: none;
	}

	a:hover {
		color: black;
	}

	.pull-right {
		float: right;
	}

	.clear-fix {
		clear: both;
	}

	#formWrapper {
		width: 100%;
		height: 90%;
		position: absolute;
		top: 0;
		left: 0;
		transition: all .3s ease;
	}

	div#form {
		position: absolute;
		width: 800px;
		height: 800px;
		background-color: #CCEBF3;
		margin: auto;
		border-radius: 20px;
		padding: 20px;
		left: 26%;
		top: 40%;
		margin-left: -180px;
		margin-top: -200px;
	}

	.title {
		text-align: center;
		margin: 0%;
	}

	.title h1 {
		font-size: 60px;
		margin-bottom: 0%;
	}

	.title p {
		margin-top: 0%;
		margin-bottom: 10%;
	}

	div.form-item {
		position: relative;
		display: block;
		margin-bottom: 20px;
	}

	input {
		transition: all .2s ease;
	}

	input.form-style {
		color: #8a8a8a;
		display: block;
		width: 90%;
		height: 80px;
		padding: 20px 5%;
		border: 1px solid #ccc;
		-moz-border-radius: 27px;
		-webkit-border-radius: 27px;
		border-radius: 27px;
		-moz-background-clip: padding;
		-webkit-background-clip: padding-box;
		background-clip: padding-box;
		background-color: #fff;
		font-size: 200%;
		letter-spacing: .8px;
	}

	div.form-item .form-style:focus {
		outline: none;
		border: 1px solid gray;
		color: gray;
	}

	div.form-item p.formLabel {
		position: absolute;
		left: 26px;
		top: 2px;
		transition: all .4s ease;
		color: #bbb;
	}

	input[type="submit"].login {
		width: 100%;
		height: 100px;
		border-radius: 19px;
		font-size: 20px;
		-moz-background-clip: padding;
		-webkit-background-clip: padding-box;
		background-clip: padding-box;
		background-color: black;
		border: none;
		color: white;
		font-weight: bold;
	}

	input[type="submit"].login:hover {
		background-color: black;
		color: white;
		cursor: pointer;
	}

	input[type="submit"].login:focus {
		outline: none;
	}

	.register-text {
		text-align: center;
		font-size: 30px;
	}

	.register-link {
		color: black;
		font-weight: bolder;
	}

	#remember {
		margin-bottom: 20px;
	}
</style>

<body>
	<!--font-->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&family=Raleway:wght@200&display=swap"
		rel="stylesheet">

	<header id="header">
		<a href="http://localhost/SpeechSDK-JavaScript_%E6%88%90%E5%8A%9F!/speech_home.php">
			<p class="speech_logo">BilingoSpeak</p>
		</a>
	</header>

	<section id="big_pic">

		<form action="register.php" method="POST">
			<div id="formWrapper">
				<div id="form">
					<div class="title">
						<h1>REGISTER</h1>
						<p><small></small></p>
					</div>
					<div class="form-item">
						<input type="char" name="username" placeholder="user name" id="Name" class="form-style" />
					</div>
					<div class="show">
						<div class="form-item">
							<input type="char" name="ID" placeholder="e-mail" id="ID" class="form-style" />
						</div>
						<div class="form-item">
							<input type="password" name="password" placeholder="password" id="password"
								class="form-style" />
							<!-- <div class="pw-view"><i class="fa fa-eye"></i></div> -->
							<!--<p><a href="purchArt_home.html"><small>Log in</small></a></p>-->
						</div>
					</div>
					<div class="form-item">
						<input type="submit" class="login pull-right" value="Submit">
						<div class="clear-fix">
						</div>
						<p class="register-text">Already have an account? <a href="login.html" class="register-link">Login</a>
						</p>

					</div>
				</div>
			</div>

		</form>

	</section>


</body>

</html>
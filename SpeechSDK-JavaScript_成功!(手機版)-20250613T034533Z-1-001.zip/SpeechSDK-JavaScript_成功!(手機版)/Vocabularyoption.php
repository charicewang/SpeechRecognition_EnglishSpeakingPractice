<?php
session_start();  //很重要，可以用的變數存在session裡
/*$user_id = $_SESSION["id"];*/
$user_icon = $_SESSION["icon"];
$user_name = $_SESSION["name"];
/*$user_intro = $_SESSION["intro"];
$user_occu = $_SESSION["occu"];*/

mb_internal_encoding("UTF-8");
//連結資料庫
$link = new PDO("mysql:dbname=EnglishSpeakingTrainingApp;host=localhost","root","0000");
?>

<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <title>Speaking practice</title>
    <link rel="stylesheet" type="text/css" href="header.css">
    <link rel="stylesheet" type="text/css"
        href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
    <link rel="stylesheet" type="text/css"
        href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-2-9/css/5-2-9.css">
    <link href="record2.css" rel="stylesheet">
    <script src="microsoft.cognitiveservices.speech.sdk.bundle.js"></script>
    <script src="final6.js"></script>
</head>

<script>var a = 1;</script>

<style>
    footer {
        background-color: gainsboro;
        margin: 0px;
        padding: 1%;
        text-align: center;
    }
    /* 定義三欄佈局的容器 */
    .container {
        display: flex;
        height:100%;
    }

    /* 中間分栏的樣式 */
    .middle-column {
        flex: 2;
        width: 20%;
        background-color: #E8E7E7;
        min-height: 600px;
        height:1500px;
    }

    /* 中間分栏區隔的樣式 */
    .middle-separator {
        border-left: 1px solid #ccc;
        border-right: 1px solid #ccc;
        padding-left: 30px;
        padding-right: 30px;
        padding-bottom: 30px;
    }

    hr {
        position: static;
    }


    .question-button {
        padding: 15px 15px;
        border-radius: 25px;
        width: 90%;
        text-align: left;
        font-size: 20px;
        background-color: #fff;
        border: 1px solid #ccc;
        margin-bottom: 20px;
        cursor: pointer;
    }

    .record-button-container {
        display: flex;
        justify-content: center;
        margin-bottom: 0px;
        margin-top: 20px;
        background-color: #CCEBF3;
    }

    .record-button-container div {
        position: absolute;
        top: 93%;
    }

    #recordButton {
        background-color: #CCEBF3;
    }

    /* 按鈕樣式 */
    .guide-button {
        padding: 15px 15px;
        width: 100%;
        text-align: left;
        font-size: 20px;
        background-color: #465A93;
        color: #fff;
        border: 1px solid #465A93;
        cursor: pointer;
    }

    .guide-button:hover {
        background-color: #8C52FF;
    }

    .guide-container {
        position: absolute;
        width: 100%;
        left: 0%;
        top: 40%;
    }

    .container-option {
        padding: 1rem;
    }

    .speech_logo {
        font-size: 50px;
        font-weight: bold;
        text-align:center;
        /*position: absolute;
        right:5%;*/

        /*color: orange;*/
    }

    .drop {
        position: relative;
        left: 10%;
        display: block;
        width: 80%;
        margin: 0 0 10px;

        &:hover {
            .dropOption {
                display: block;
            }
        }

        &:hover {
            .dropdown {
                display: block;
            }
        }

        &:hover {
            .dropdown.close {
                display: none;
            }
        }

        .dropOption {
            position: relative;
            margin-top:100px;
            width: 100%;
            color: #666;
            font-size: 60px;
            background-color: #fff;
            padding: 10px;
            border: 1px solid #888;
            border-radius: 5px;
            box-sizing: border-box;
            cursor: pointer;

            &::after {
                content: "";
                position: absolute;
                top: 20px;
                right: 12px;
                border-width: 8px 6px;
                border-style: solid;
                border-color: #999 transparent transparent transparent;
            }
        }

        .dropdown {
            display: none;
            width: 100%;
            max-height: 900px;
            position: absolute;
            color: #333;
            padding: 0;
            margin: 0;
            background-color: #f9f9f9;
            box-shadow: 0px 2px 3px 0px #ccc;
            border-radius: 6px;
            box-sizing: border-box;
            overflow: auto;
            z-index: 10;

            >li {
                display: block;
                color: #000;
                padding: 12px;
                font-size: 60px;
                margin: 0 10px;
                cursor: pointer;

                &:first-child {
                    margin: 10px;
                }

                &:last-child {
                    margin-bottom: 10px;
                }

                &:hover {
                    background-color: #465A93;
                    color: white;
                    border-radius: 6px;
                }
            }

            &::-webkit-scrollbar {
                width: 15px;
            }

            &::-webkit-scrollbar-track {
                background-color: #eee;
                border-radius: 6px;
            }

            &::-webkit-scrollbar-thumb {
                background-color: #465A93;
                border-radius: 15px;
            }

            &::-webkit-scrollbar-button {
                background-color: #f9f9f9;
            }
        }
    }

    nav li.has-child>div {
    position: absolute;
    z-index: 9999; /* 一个较高的数值，确保它位于其他元素上方 */
    border-radius: 5%;
    right: 0;
    top: 62px;
    background: white;
    width: 200px;
    visibility: hidden;
    opacity: 0;
    transition: all .3s;
}

.introtext{
    font-size:40px;
}
</style>

<body>
    <header id="header">
        <a href="speech_home.php" class="logo">
            <p class="speech_logo">BilingoSpeak</p>
        </a>
        <nav>
            <ul>
                <li class="has-child"><img class="icon" src="three.jpg"> <!--class="in"-->
                    <div>
                        <ul>
                            <div class="pro_icon">
                                <img src="<?php echo $user_icon; ?>">
                                <div class="info">
                                    <p><?php echo $user_name; ?></p>
                                </div>
                            </div>
                            <li class="menu"><a href="ABOUT US.html">Profile</a></li>
                            <li class="menu"><a href="speech_home.php">Home</a></li>
                            <li class="menu"><a href="#">About</a></li>
                            <li class="menu"><a href="編輯畫面.html">Practice</a></li>
                            <li class="menu"><a href="record.php">Record</a></li>
                            <li class="menu"><a href="#">setting</a></li>
                            <li class="menu"><a href="speech_home_before_login.php">LOG OUT</a></li>
                            <br>
                        </ul>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
        <!--<div class="wall"></div>-->
        <hr class="hr-1">
    <hr class="hr-2">
    <div class="container">
        <div class="middle-column">
            <div class="option-box"></div>
            <div class="container-option">
                <div class="drop">
                    <h1 class="introtext">Vocabulary Practice</h1>
                    <div class="dropOption">
                        <span>請選擇要練習的單字集</span>
                    </div>

                    <?php 
                        /*$phpVariableZERO = "Random";
                        $phpVariableA = "A";
                        $phpVariableB = "B";
                        $phpVariableC = "C";
                        $phpVariableD = "D";
                        $phpVariableE = "E";
                        $phpVariableF = "F";
                        $phpVariableG = "G";*/
                    ?>

                    <ul class="dropdown">
                        <!--這裡處理一下-->
                    <!--<form action="welcome.php" method="get">
                        Name: <input type="text" name="fname">
                        Age: <input type="text" name="age">
                        <input type="submit">
                    </form>-->
                        <!--<li><a href="Vocabularyfix.php?data=Random" class="option">Random</a></li>-->
                        <li><a href="Vocabularyfix.php?data=A" class="option">A</a></li>
                        <li><a href="Vocabularyfix.php?data=B" class="option">B</a></li>
                        <li><a href="Vocabularyfix.php?data=C" class="option">C</a></li>
                        <li><a href="Vocabularyfix.php?data=D" class="option">D</a></li>
                        <li><a href="Vocabularyfix.php?data=E" class="option">E</a></li>
                        <li><a href="Vocabularyfix.php?data=F" class="option">F</a></li>
                        <li><a href="Vocabularyfix.php?data=G" class="option">G</a></li>
                        <li><a href="Vocabularyfix.php?data=H" class="option">H</a></li>
                        <li><a href="Vocabularyfix.php?data=I" class="option">I</a></li>
                        <li><a href="Vocabularyfix.php?data=J" class="option">J</a></li>
                        <li><a href="Vocabularyfix.php?data=K" class="option">K</a></li>
                        <li><a href="Vocabularyfix.php?data=L" class="option">L</a></li>
                        <li><a href="Vocabularyfix.php?data=M" class="option">M</a></li>
                        <li><a href="Vocabularyfix.php?data=N" class="option">N</a></li>
                        <li><a href="Vocabularyfix.php?data=O" class="option">O</a></li>
                        <li><a href="Vocabularyfix.php?data=P" class="option">P</a></li>
                        <li><a href="Vocabularyfix.php?data=Q" class="option">Q</a></li>
                        <li><a href="Vocabularyfix.php?data=R" class="option">R</a></li>
                        <li><a href="Vocabularyfix.php?data=S" class="option">S</a></li>
                        <li><a href="Vocabularyfix.php?data=T" class="option">T</a></li>
                        <li><a href="Vocabularyfix.php?data=U" class="option">U</a></li>
                        <li><a href="Vocabularyfix.php?data=V" class="option">V</a></li>
                        <li><a href="Vocabularyfix.php?data=W" class="option">W</a></li>
                        <li><a href="Vocabularyfix.php?data=X" class="option">X</a></li>
                        <li><a href="Vocabularyfix.php?data=Y" class="option">Y</a></li>
                        <li><a href="Vocabularyfix.php?data=Z" class="option">Z</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--頁尾-->
    <footer>
        <p>@other information</p>
    </footer>
</body>

</html>

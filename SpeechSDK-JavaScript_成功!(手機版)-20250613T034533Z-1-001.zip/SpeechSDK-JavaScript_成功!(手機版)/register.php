<?php
mb_internal_encoding("UTF-8");
$host = 'localhost';
$dbuser ='root';
$dbpassword = '0000';
$dbname = 'EnglishSpeakingTrainingApp';
$link = mysqli_connect($host,$dbuser,$dbpassword,$dbname);
mysqli_query($link, 'SET NAMES utf8');
/*if($link){
    echo "正確連接資料庫";
}

else {
    echo "不正確連接資料庫</br>" . mysqli_connect_error();
}*/

if($_SERVER["REQUEST_METHOD"]=="POST"){
    mb_internal_encoding("UTF-8");
    $username=$_POST["username"];
    $email=$_POST["ID"];
    $password=$_POST["password"];
    //$uIcon=$_POST["uIcon"];
    //檢查帳號是否重複
    $check="SELECT * FROM User WHERE uID='".$username."'";
    if(mysqli_num_rows(mysqli_query($link,$check))==0){
        $sql = "INSERT INTO  User(uID,email,password,uIcon) VALUES ('".$username."','".$email."','".$password."','dog.jpg') ";
        
        if(mysqli_query($link, $sql)){
            echo "註冊成功!3秒後將自動跳轉頁面<br>";
            echo "<a href='login.html'>未成功跳轉頁面請點擊此</a>";
            header('refresh:3; url=login.html');
            exit;
        }else{
            echo "Error creating table: " . mysqli_error($link);
        }
    }
    else{
        echo "該帳號已有人使用!<br>3秒後將自動跳轉頁面<br>";
        echo "<a href='login.html'>未成功跳轉頁面請點擊此</a>";
        header('HTTP/1.0 302 Found');
        header("refresh:3;url=login.html",true);
        exit;
    }
}


mysqli_close($link);

function function_alert($message) { 
      
    // Display the alert box  
    echo "<script>alert('$message');
     window.location.href='index1.php';
    </script>"; 
    
    return false;
} 
?>
<?php
session_start();  //很重要，可以用的變數存在session裡
/*$user_id = $_SESSION["id"];*/
$user_icon = $_SESSION["icon"];
$user_name = $_SESSION["name"];
/*$user_intro = $_SESSION["intro"];
$user_occu = $_SESSION["occu"];*/

mb_internal_encoding("UTF-8");
//echo $_GET['data'];
$phpVariable = $_GET['data'];

//要的$phpVariable = $_GET['phpVariable'];
//output: Dog
//連結資料庫
$link = new PDO("mysql:dbname=EnglishSpeakingTrainingApp;host=localhost","root","0000");
//dining
//$result = $link->query("select * from question where qtype = 'Food_and_Dining';");
//可以這樣寫
/*$result = $link->query("select * from question where qtype = $phpVariable;");

$i = 0;
while($row=$result->fetch()){
   $arr_text_content_data[$i] = $row['text_content'];   
   ++$i;
   }
*/

$stmt = $link->prepare("SELECT * FROM question WHERE qtype = :qtype");

// 繫結參數
$stmt->bindParam(':qtype', $phpVariable, PDO::PARAM_STR);
   
// 執行查詢
$stmt->execute();
   
// 取得結果
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$i = 0;
foreach ($result as $row) {
    // 處理每一列的資料
    $arr_text_content_data[$i] = $row['text_content'];   
    ++$i;
}


?>

<?php
$phpVariableHA = "Hello from PHP!";
?>

<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <title>Speaking practice</title>
    <link rel="stylesheet" type="text/css" href="header.css">
    <link rel="stylesheet" type="text/css"
        href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
    <link rel="stylesheet" type="text/css"
        href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-2-9/css/5-2-9.css">
    <link href="record2.css" rel="stylesheet">
    <script src="microsoft.cognitiveservices.speech.sdk.bundle.js"></script>
    <!--<script src="test10.js"></script>-->
</head>

<script>var a = 1;</script>
<style>
    footer {
        background-color: gainsboro;
        margin: 0px;
        padding: 1%;
        text-align: center;
    }
    /* 定義三欄佈局的容器 */
    .container {
        display: flex;
        height:100%;
    }


    /*成績顯示*/
    .info {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        max-height:300px;
    }

    .score-text {
        font-size: 40px;
        font-weight: bold;
    }

    .score-image-container {
        margin: 15px;
        margin-top:-40px;
        display: flex;
        width: 160px;
        height: 160px;
        position: relative;
        /*top: 50%;*/
        /*left: 30%;*/
        border-radius: 50%;
        border: 10px solid #465A93;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
        justify-content: center;
        /* 水平居中 */
        align-items: center;
        /* 垂直居中 */
        font-size: 40px;
        font-weight: bolder;
        background-color: #F0EEE2;
    }

    .score-image-container span{
        font-size:50px;
    }

    .info div p {
    text-align: center;
    font-weight: bolder;
    font-size:30px;
}


    /* 右側分栏的樣式 */
    .right-column {
        flex: 2;
        width: 60%;
        /*max-width: 400px;*/
        padding: 20px;
        background-color: #E8E7E7;
        position: relative;
        /* 讓按鈕定位於此 */
        min-height: 600px;
        max-height: 1500px;

    }

    /* 聊天室對話框的樣式 */
    .chat-box {
        margin-top: 60px;
        max-width: 100%;
        min-height: 300px;
        max-height: 1050px;
        /*height: 200px;*/
        overflow-y: auto;
        border: 1px solid #ccc;
        padding: 10px;
        background-color: #fff;
        border-radius: 20px;
        /* 設定圓角背景框 */
    }

    .chat-box-score {
        margin-top: 10px;
        max-width: 100%;
        min-height: 300px;
        max-height: 900px;
        /*height: 200px;*/
        overflow-y: auto;
        border: 1px solid #ccc;
        padding: 10px;
        background-color: #F0EEE2;
        border-radius: 10px;
        /* 設定圓角背景框 */
    }

    .chat-container {
        display: flex;
        flex-direction: column;
        position: relative;
        text-align: left;
        font-size: 20px;
        min-height: 900px;
    }

    hr {
        position: static;
    }


    .question-button {
        padding: 15px 15px;
        border-radius: 25px;
        width: 90%;
        text-align: left;
        font-size: 20px;
        background-color: #fff;
        border: 1px solid #ccc;
        margin-bottom: 20px;
        cursor: pointer;
    }

    .record-button-container {
        display: flex;
        justify-content: center;
        margin-bottom: 0px;
        margin-top: 20px;
        background-color: #CCEBF3;
    }

    .record-button-container div {
        position: absolute;
    }

    #recordButton {
        background-color: #CCEBF3;
        position: relative;
        margin-top:50px;
        left: 50%;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        background-image: url(mic.png);
        background-size: cover;
        border: none;
        cursor: pointer;
        transform: translateX(-50%);
        display: flex;
        align-items: center;
        justify-content: center;
    }

    #listen-button{
        background-color: #CCEBF3;
        /*以下都要改*/
        position: relative;
        top: 10%;
        margin-left:20px;
        /* 調整按鈕與底部的距離 */
        width: 30px;
        height: 30px;
        border-radius: 50%;
        /* 將按鈕變成圓形，border-radius 設為寬度的一半 */
        background-image: url('speaker.png');
        /* 設置按鈕的背景圖片 */
        background-size: cover;
        border: none;
        cursor: pointer;
    }


    #scoreButton {
        position: absolute;
        background-color: #465A93;
        color: white;
        border-radius: 12%;
        bottom: -30%;
        left: 30%;
        width: 200px;
        height: 60px;
        background-size: cover;
        border: none;
        cursor: pointer;
        transform: translateX(-50%);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size:30px;
    }

    #restartButton {
        position: absolute;
        background-color: #465A93;
        color: white;
        border-radius: 12%;
        bottom: -30%;
        left: 70%;
        width: 200px;
        height: 60px;
        /*border-radius: 30%;*/
        background-size: cover;
        border: none;
        cursor: pointer;
        transform: translateX(-50%);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size:30px;
    }

    /* 按鈕樣式 */
    .guide-button {
        padding: 15px 15px;
        width: 100%;
        text-align: left;
        font-size: 20px;
        background-color: #465A93;
        color: #fff;
        border: 1px solid #465A93;
        cursor: pointer;
    }

    .guide-button:hover {
        background-color: #8C52FF;
    }

    .guide-container {
        position: absolute;
        width: 100%;
        left: 0%;
        top: 40%;
    }

    .info div p {
        text-align: center;
        font-weight: bolder;
    } 

    .speaking-text {
        color: blue;
    }

    .speaking-text-wrong {
        color: red;
        cursor: pointer; /* 鼠标指针显示为手型，表示可以点击 */
    }

    .notice {
        text-align:left;
        font-size:40px;
    }

    .advise{
        margin:20px;
        font-size:30px;
    }

    .speech_logo {
        font-size: 50px;
        font-weight: bold;
        text-align:center;
        /*position: absolute;
        right:5%;*/

        /*color: orange;*/
    }

    .Question-num{
        font-size:60px;
    }

    .drop {
        position: relative;
        left: 10%;
        display: block;
        width: 80%;
        margin: 0 0 10px;

        &:hover {
            .dropOption {
                display: block;
            }
        }

        &:hover {
            .dropdown {
                display: block;
            }
        }

        &:hover {
            .dropdown.close {
                display: none;
            }
        }

        .dropOption {
            position: relative;
            margin-top:100px;
            width: 100%;
            color: #666;
            font-size: 60px;
            background-color: #fff;
            padding: 10px;
            border: 1px solid #888;
            border-radius: 5px;
            box-sizing: border-box;
            cursor: pointer;

            &::after {
                content: "";
                position: absolute;
                top: 20px;
                right: 12px;
                border-width: 8px 6px;
                border-style: solid;
                border-color: #999 transparent transparent transparent;
            }
        }

        .dropdown {
            display: none;
            width: 100%;
            max-height: 900px;
            position: absolute;
            color: #333;
            padding: 0;
            margin: 0;
            background-color: #f9f9f9;
            box-shadow: 0px 2px 3px 0px #ccc;
            border-radius: 6px;
            box-sizing: border-box;
            overflow: auto;
            z-index: 10;

            >li {
                display: block;
                color: #000;
                padding: 12px;
                font-size: 60px;
                margin: 0 10px;
                cursor: pointer;

                &:first-child {
                    margin: 10px;
                }

                &:last-child {
                    margin-bottom: 10px;
                }

                &:hover {
                    background-color: #465A93;
                    color: white;
                    border-radius: 6px;
                }
            }

            &::-webkit-scrollbar {
                width: 15px;
            }

            &::-webkit-scrollbar-track {
                background-color: #eee;
                border-radius: 6px;
            }

            &::-webkit-scrollbar-thumb {
                background-color: #465A93;
                border-radius: 15px;
            }

            &::-webkit-scrollbar-button {
                background-color: #f9f9f9;
            }
        }
    }

    nav li.has-child>div {
    position: absolute;
    z-index: 9999; /* 一个较高的数值，确保它位于其他元素上方 */
    border-radius: 5%;
    right: 0;
    top: 62px;
    background: white;
    width: 200px;
    visibility: hidden;
    opacity: 0;
    transition: all .3s;
}

#content{
    font-size:40px;
}

#again_button{
    position: relative;
    background-color: #465A93;
    color: white;
    border-radius: 12%;
    left: 50%;
    bottom:-5%;
    width: 200px;
    height: 60px;
    /*border-radius: 30%;*/
    background-size: cover;
    border: none;
    cursor: pointer;
    transform: translateX(-50%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size:30px;
}
</style>


<body>
<header id="header">
        <a href="speech_home.php" class="logo">
            <p class="speech_logo">BilingoSpeak</p>
        </a>
        <nav>
            <ul>
                <li class="has-child"><img class="icon" src="three.jpg"> <!--class="in"-->
                    <div>
                        <ul>
                            <div class="pro_icon">
                                <img src="<?php echo $user_icon; ?>">
                                <div class="info">
                                    <p><?php echo $user_name; ?></p>
                                </div>
                            </div>
                            <li class="menu"><a href="ABOUT US.html">Profile</a></li>
                            <li class="menu"><a href="speech_home.php">Home</a></li>
                            <li class="menu"><a href="#">About</a></li>
                            <li class="menu"><a href="編輯畫面.html">Practice</a></li>
                            <li class="menu"><a href="record.php">Record</a></li>
                            <li class="menu"><a href="#">setting</a></li>
                            <li class="menu"><a href="speech_home_before_login.php">LOG OUT</a></li>
                            <br>
                        </ul>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <hr class="hr-1">
    <hr class="hr-2">
    <div class="container">
        <div class="right-column" id="right-column">
            <div class="chat-box">
                <div class="Question-num">Read the text as it's written:</div>
                <hr>
                <div class="chat-container">
                    <div><br></div>
                    <div id="content"><?php echo $arr_text_content_data[0]; ?><!--The special gift was a letter from my grandparents. It's not so much the letter itself as words of wisdom from my grandparents. They listed the kind of the predicament I am going to face in the following twenty years. It was written in cursive writing of course and looks tattered. It's like the prophecy of my life in the next two decades, totally looks like the clay tablet in The Richest Man in Babylon. Since it was too invaluable, I used to put it in the safe, and now I'm handling it to my kid-kind of reminding them the gestures from their great grandparents and would like them to pass on to their kids and so on.--></div>
                
                </div>
            </div>
            <div class="record-button-container">
                <div><button id="recordButton" onclick="main()"></button></div>
            </div>
            <button id="scoreButton">Finish</button>
            <button id="restartButton">Restart</button>
        </div>
    </div>
    
    <script>
        var resultDiv = document.getElementById('result'); //顯示提示訊息，可刪除
var mediaRecorder;
var recordedChunks = [];
var isRecording = false;
var stream;
const scoreNumber = {
    accuracyScore: 0,
    fluencyScore: 0,
    compScore: 0,
};
const allWords = [];
var currentText = [];
var startOffset = 0;
var recognizedWords = [];
var fluencyScores = [];
var durations = [];
var jo = {};
var textContents = [];
var scoreContents = [];
var orgtext = [];
var pronunciationErrors = [];
var textWithoutPunctuation = [] //不含標點

var jsVariable = <?php echo json_encode($arr_text_content_data[0]); ?>;
console.log(jsVariable);



SPEECH_KEY = "5a248214ebc74d1cbdd37688dd685b77";
SPEECH_REGION = "eastus";
const referenceText = jsVariable;
//const referenceText = "The special gift was a letter from my grandparents. It's not so much the letter itself as words of wisdom from my grandparents. They listed the kind of the predicament I am going to face in the following twenty years. It was written in cursive writing of course and looks tattered. It's like the prophecy of my life in the next two decades, totally looks like the clay tablet in The Richest Man in Babylon. Since it was too invaluable, I used to put it in the safe, and now I'm handling it to my kid-kind of reminding them the gestures from their great grandparents and would like them to pass on to their kids and so on.";
const wordsWithPunctuation = referenceText.match(/\b\w+\b|[.,;!?']/g);

function main() {

    startRecording();
    var recordButton = document.getElementById("recordButton");
    recordButton.classList.add('active'); // 添加 active 類別，使按鈕變色並開始閃爍

    const audioConfig = SpeechSDK.AudioConfig.fromDefaultMicrophoneInput();
    var speechConfig = SpeechSDK.SpeechConfig.fromSubscription(SPEECH_KEY, SPEECH_REGION);

    // create pronunciation assessment config
    var pronunciationAssessmentConfig = new SpeechSDK.PronunciationAssessmentConfig(
        referenceText,
        SpeechSDK.PronunciationAssessmentGradingSystem.HundredMark,
        SpeechSDK.PronunciationAssessmentGranularity.Phoneme,
        true
    );

    // setting the recognition language to English.
    speechConfig.speechRecognitionLanguage = "en-US";

    // create the speech recognizer
    var recognizer = new SpeechSDK.SpeechRecognizer(speechConfig, audioConfig);
    pronunciationAssessmentConfig.applyTo(recognizer);

    recognizer.startContinuousRecognitionAsync(); //Start continuous recognition

    recognizer.recognized = function (s, e) {
        if (e.result.reason === SpeechSDK.ResultReason.RecognizedSpeech) {
            var pronunciationResult = SpeechSDK.PronunciationAssessmentResult.fromResult(e.result);
            var pa = pronunciationResult.accuracyScore;
            var pp = pronunciationResult.pronunciationScore;
            var pc = pronunciationResult.completenessScore;
            var pf = pronunciationResult.fluencyScore;
            scoreContents.push([pa, pp, pc, pf]); //將textContent添加到陣列中
            var recognizedText = e.result.text; // 儲存識別的原始文本
            orgtext.push(recognizedText);
            console.log("pronunciation assessment for: ", e.result.text);
            console.log(" Accuracy score: ", pronunciationResult.accuracyScore, '\n',
                "pronunciation score: ", pronunciationResult.pronunciationScore, '\n',
                "completeness score : ", pronunciationResult.completenessScore, '\n',
                "fluency score: ", pronunciationResult.fluencyScore,
            );


            console.log("  Word-level details:");
            pronunciationResult.detailResult.Words.forEach((word, idx) => {
                var textContent = word.Word + " ";
                word.PronunciationAssessment.AccuracyScore
                textContents.push([textContent, word.PronunciationAssessment.AccuracyScore]);
                console.log("    ", idx + 1, ": word: ", word.Word, "accuracy score: ", word.PronunciationAssessment.AccuracyScore, "error type: ", word.PronunciationAssessment.ErrorType, ";");
            });
            //recognizer.close();


            recordButton.addEventListener("click", function () {
                stopRecording();
                recordButton.classList.remove('active'); //移除 active 類別，停止閃爍
                saveScore();
                recognizer.stopContinuousRecognitionAsync(); // 停止連續識別
            });
        }
    };
}

async function startRecording() {
    try {
        recordedChunks = [];// 重置錄音數據陣列
        stream = await navigator.mediaDevices.getUserMedia({
            audio: true
        });
        mediaRecorder = new MediaRecorder(stream);

        mediaRecorder.ondataavailable = function (event) {
            if (event.data.size > 0) {
                recordedChunks.push(event.data);
            }
        };

        mediaRecorder.onstop = function () {
            isRecording = false;
            saveRecording();
        };

        mediaRecorder.start();
        isRecording = true;
    } catch (error) {
        resultDiv.textContent = '無法獲取麥克風訪問權限: ' + error.message;
    }
}

function stopRecording() {
    mediaRecorder.stop();
    stream.getTracks().forEach(track => track.stop());
}

function saveRecording() {
    var blob = new Blob(recordedChunks,
        {
            type: 'audio/ogg'
        });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'recorded_data.ogg';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);
    /*var saved = document.getElementById('result');
    saved.textContent = "錄音已完成並儲存至\"我的練習\"。";*/
}


//測試用的
function saveScore() {
    var scorebutton = document.getElementById("scoreButton");
    console.log("Received textContentsArray: ", textContents);


    scorebutton.addEventListener("click", function () {
        var rightcolumn = document.getElementById("right-column");
        rightcolumn.innerHTML = `
        <div class="info">
            <!--左側區塊-->
            <div>
                <div class="score-image-container">
                    <span id="pronunciationScore">100%</span>
                </div>
                <p>Pronunciation<br>Score</p>
            </div>
            <div>
                <div class="score-image-container">
                    <span id="accuracyScore"></span>
                </div>
                <p>Accuracy<br>Score</p>
            </div>    
            <div>
                <div class="score-image-container">
                    <span id="completenessScore"></span>
                </div>
                <p>Completeness<br>Score</p>
            </div>    
            <div>
                <div class="score-image-container">
                    <span id="fluencyScore"></span>
                </div>
                <p>Fluency<br>Score</p>
            </div>
        </div>
        <hr>
        <p class="notice">You should improve your pronunciation of the following words:</p>
            <div class="chat-box-score">
                <div class="chat-container">
                    <div id="content">
                    </div>
                    <div id="ha"></div>
                </div>
            </div>
            <a href="test.php?data=<?php echo $phpVariable; ?>"><button id="again_button">Try again!</button></a>
        </div>
`;
        var accuracyScoreElement = document.getElementById('accuracyScore');
        var pronunciationScoreElement = document.getElementById('pronunciationScore');
        var completenessScoreElement = document.getElementById('completenessScore');
        var fluencyScoreElement = document.getElementById('fluencyScore');

        var totalAccuracyScore = 0; //用來總和所有第一個元素的值
        var totalpronunciationScore = 0;
        var totalcompletenessScore = 0;
        var totalfluencyScore = 0;
        var count = 0; // 用來記錄迭代的次數

        for (var scorerow of scoreContents) {
            var allpa = scorerow[0]; // 獲取每一列的第一個元素
            var allpp = scorerow[1]; // 获取每一列的第二个元素
            var allpc = scorerow[2];
            var allpf = scorerow[3];

            // 將每一列的第一個元素的值添加到總和變數中
            totalAccuracyScore += allpa;
            totalpronunciationScore += allpp;
            totalcompletenessScore += allpc;
            totalfluencyScore += allpf;

            count++;
        }

        // 計算平均值
        var averageAccuracyScore = (totalAccuracyScore / count).toFixed(1);
        var averagepronunciationScore = (totalpronunciationScore / count).toFixed(1);
        var averagecompletenessScore = (totalcompletenessScore / count).toFixed(1);
        var averagefluencyScore = (totalfluencyScore / count).toFixed(1);


        // 创建一个包含数据的对象
        var data = {
            averageAccuracyScore: averageAccuracyScore,
            averagepronunciationScore: averagepronunciationScore,
            averagecompletenessScore: averagecompletenessScore,
            averagefluencyScore: averagefluencyScore
        };

        // 创建一个 XMLHttpRequest 对象
        var xhr = new XMLHttpRequest();

        // 设置请求方法和 URL
        xhr.open('POST', '', true);

        // 设置请求头，以便告诉服务器发送的是 JSON 数据
        xhr.setRequestHeader('Content-Type', 'application/json');

        // 定义在请求完成时执行的回调函数
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // 处理服务器响应
                console.log(xhr.responseText);
        }
};

// 发送请求，并将数据转换为 JSON 字符串
xhr.send(JSON.stringify(data));


        accuracyScoreElement.textContent = averageAccuracyScore;
        pronunciationScoreElement.textContent = averagepronunciationScore;//整體分數
        completenessScoreElement.textContent = averagecompletenessScore;
        fluencyScoreElement.textContent = averagefluencyScore;

        var content = document.getElementById("content");
        var fragment = document.createDocumentFragment();

        <?php
// 检查是否是 POST 请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取通过 POST 请求发送的数据
    $data = json_decode(file_get_contents("php://input"));

    // 提取数据
    $averageAccuracyScore = $data->averageAccuracyScore;
    $averagepronunciationScore = $data->averagepronunciationScore;
    $averagecompletenessScore = $data->averagecompletenessScore;
    $averagefluencyScore = $data->averagefluencyScore;

    // 在此处进行进一步的处理，例如插入数据库等
    mb_internal_encoding("UTF-8");
$host = 'localhost';
$dbuser ='root';
$dbpassword = '0000';
$dbname = 'EnglishSpeakingTrainingApp';
$conn = mysqli_connect($host,$dbuser,$dbpassword,$dbname);
// 创建数据库连接

// 检查连接是否成功
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 构造 SQL 查询字符串
$sql = "INSERT INTO user_score (scoreid, username, scoretype, averageAccuracyScore, averagepronunciationScore, averagecompletenessScore, averagefluencyScore, date_time) VALUES ('', '$user_name', '$phpVariable', '$averageAccuracyScore', '$averagepronunciationScore', '$averagecompletenessScore', '$averagefluencyScore', NOW())";

// 执行 SQL 查询
if ($conn->query($sql) === TRUE) {
    echo "Data inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// 关闭数据库连接
$conn->close();
}
?>        

        for (var row of textContents) {
            var firstElement = row[0]; // 获取每一列的第一个元素
            var secondElement = row[1]; // 获取每一列的第二个元素


            // 创建一个新的 <span> 元素
            let span = document.createElement("span");
            span.classList.add('speaking-text');

            if (secondElement < 90) {
                span.classList.add('speaking-text-wrong');
            }
        }

        let i = 0;

        for (const row of textContents) {
            const wordWithPunctuation = wordsWithPunctuation[i];
            var eachscore = row[1];
            const wordWithoutPunctuation = row[0];
            // 模拟发音评分，这里假设 "gift" 是一个发音错误的单词
            if (eachscore < 80) {
                pronunciationErrors.push(i);
            }


            i++; // 计数器递增
            if (i >= wordsWithPunctuation.length) {
                break; // 如果 i 达到或超过 wordsWithPunctuation 的长度，退出循环
            }
        }

        // 标记发音错误的单词为红色
        const markedText = referenceText
            .split(' ')
            .map((word, index) => {
                let span = document.createElement("span");
                span.classList.add('speaking-text');
                if (pronunciationErrors.includes(index)) {
                    span.classList.add('speaking-text-wrong');
                }
                span.appendChild(document.createTextNode(word + ' '));
                fragment.appendChild(span);
            })


        while (fragment.firstChild) {
            content.appendChild(fragment.firstChild);
        }

        // 遍历所有具有 "speaking-text-wrong" 类的单词
        const speakingtextwrong = document.querySelectorAll('.speaking-text-wrong');
        speakingtextwrong.forEach(word => {
            word.addEventListener('click', () => {
                // 播放正确的发音
                console.log("hallo");
                var textToRead = word.textContent;  // 使用被點擊的單詞的文本內容
                // 創建 SpeechSynthesisUtterance 對象
                var utterance = new SpeechSynthesisUtterance(textToRead);
                utterance.rate = 0.5; // 設置語速，預設為1
                utterance.pitch = 1; // 設置音高，預設為1

                // 使用內建的語音合成器
                window.speechSynthesis.speak(utterance);
                /*const audio = new Audio("letter.mp3");
                audio.play();*/
            });
        });
    });
}
    </script>
</body>

</html>
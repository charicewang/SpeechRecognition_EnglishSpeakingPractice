document.addEventListener('DOMContentLoaded', function () {
    var recordButton = document.getElementById('recordButton');
    var resultDiv = document.getElementById('result');
    var mediaRecorder;
    var recordedChunks = [];
    var isRecording = false;

    recordButton.addEventListener('click', function () {
        if (!isRecording) {
            startRecording();
        } else {
            stopRecording();
        }
    });

    function startRecording() {
        navigator.mediaDevices.getUserMedia({ audio: true })
            .then(function (stream) {
                mediaRecorder = new MediaRecorder(stream);

                mediaRecorder.ondataavailable = function (event) {
                    if (event.data.size > 0) {
                        recordedChunks.push(event.data);
                    }
                };

                mediaRecorder.onstop = function () {
                    isRecording = false;
                    saveRecording();
                };

                mediaRecorder.start();
                isRecording = true;
                recordButton.textContent = '停止錄音';
            })
            .catch(function (error) {
                resultDiv.textContent = '無法獲取麥克風訪問權限: ' + error.message;
            });
    }

    function stopRecording() {
        mediaRecorder.stop();
        recordButton.textContent = '開始錄音';
    }

    function saveRecording() {
        var blob = new Blob(recordedChunks, { type: 'audio/mp3' });
        var url = URL.createObjectURL(blob);

        // 這裡先將音訊的 URL 播放給使用者
        var audioElement = document.createElement('audio');
        audioElement.controls = true;
        audioElement.src = url;
        resultDiv.appendChild(audioElement);
    }
});

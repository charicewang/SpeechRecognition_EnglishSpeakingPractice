<?php
session_start();  //很重要，可以用的變數存在session裡
/*$user_id = $_SESSION["id"];*/
$user_icon = $_SESSION["icon"];
$user_name = $_SESSION["name"];
/*$user_intro = $_SESSION["intro"];
$user_occu = $_SESSION["occu"];*/

mb_internal_encoding("UTF-8");
//連結資料庫
$link = new PDO("mysql:dbname=EnglishSpeakingTrainingApp;host=localhost","root","0000");
?>

<!DOCTYPE html>
<html html lang="ja">

<head>
    <meta charset="UTF-8">
    <title>Speaking practice</title>
    <link rel="stylesheet" type="text/css" href="header.css">
    <link rel="stylesheet" type="text/css"
        href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/reset.css">
    <link rel="stylesheet" type="text/css"
        href="https://coco-factory.jp/ugokuweb/wp-content/themes/ugokuweb/data/5-2-9/css/5-2-9.css">
    <link href="record2.css" rel="stylesheet">
    <script src="microsoft.cognitiveservices.speech.sdk.bundle.js"></script>
    <script src="final6.js"></script>
</head>

<script>var a = 1;</script>

<style>
    footer {
        background-color: gainsboro;
        margin: 0px;
        padding: 1%;
        text-align: center;
    }
    /* 定義三欄佈局的容器 */
    .container {
        display: flex;
        height:100%;
    }
    
    /*成績顯示*/
    .score-text {
        font-size: 40px;
        font-weight: bold;
    }

    .score-image-container {
        display: flex;
        width: 400px;
        height: 400px;
        position: relative;
        top: 50%;
        left: 30%;
        /*transform: translate(-50%, -50%);*/
        border-radius: 50%;
        /*overflow: hidden;*/
        border: 30px solid #465A93;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
        justify-content: center;
        /* 水平居中 */
        align-items: center;
        /* 垂直居中 */
        font-size: 150px;
        font-weight: bolder;
        background-color: #F0EEE2;
    }


    select{
        background-color: #b1aeae;
        color: white;
        border: 0;
        min-height: 3vh;
        min-width: 20vh;
        padding: 10px;
        border-radius: 5px;
        appearance: none;
        font-size:30px;
        text-align:center;
    }

    /* 定義三欄佈局的容器 */
    .container {
        display: flex;
        height:100%;
    }

    /* 中間分栏的樣式 */
    .middle-column {
        flex: 2;
        width: 20%;
        background-color: #E8E7E7;
        min-height: 600px;
        height:1500px;
    }

    /* 中間分栏區隔的樣式 */
    .middle-separator {
        border-left: 1px solid #ccc;
        border-right: 1px solid #ccc;
        padding-left: 30px;
        padding-right: 30px;
        padding-bottom: 30px;
    }

    hr {
        position: static;
    }


    .question-button {
        padding: 15px 15px;
        border-radius: 25px;
        width: 90%;
        text-align: left;
        font-size: 20px;
        background-color: #fff;
        border: 1px solid #ccc;
        margin-bottom: 20px;
        cursor: pointer;
    }

    .record-button-container {
        display: flex;
        justify-content: center;
        margin-bottom: 0px;
        margin-top: 20px;
        background-color: #CCEBF3;
    }

    .record-button-container div {
        position: absolute;
        top: 93%;
    }

    #recordButton {
        background-color: #CCEBF3;
    }

    /* 按鈕樣式 */
    .guide-button {
        padding: 15px 15px;
        width: 100%;
        text-align: left;
        font-size: 20px;
        background-color: #465A93;
        color: #fff;
        border: 1px solid #465A93;
        cursor: pointer;
    }

    .guide-button:hover {
        background-color: #8C52FF;
    }

    .guide-container {
        position: absolute;
        width: 100%;
        left: 0%;
        top: 40%;
    }

    .container-option {
        padding: 1rem;
    }

    .speech_logo {
        font-size: 50px;
        font-weight: bold;
        text-align:center;
        /*position: absolute;
        right:5%;*/

        /*color: orange;*/
    }

    .drop {
        position: relative;
        left: 10%;
        display: block;
        width: 80%;
        margin: 0 0 10px;

        &:hover {
            .dropOption {
                display: block;
            }
        }

        &:hover {
            .dropdown {
                display: block;
            }
        }

        &:hover {
            .dropdown.close {
                display: none;
            }
        }

        .dropOption {
            position: relative;
            margin-top:100px;
            width: 100%;
            color: #666;
            font-size: 60px;
            background-color: #fff;
            padding: 10px;
            border: 1px solid #888;
            border-radius: 5px;
            box-sizing: border-box;
            cursor: pointer;

            &::after {
                content: "";
                position: absolute;
                top: 20px;
                right: 12px;
                border-width: 8px 6px;
                border-style: solid;
                border-color: #999 transparent transparent transparent;
            }
        }

        .dropdown {
            display: none;
            width: 100%;
            max-height: 900px;
            position: absolute;
            color: #333;
            padding: 0;
            margin: 0;
            background-color: #f9f9f9;
            box-shadow: 0px 2px 3px 0px #ccc;
            border-radius: 6px;
            box-sizing: border-box;
            overflow: auto;
            z-index: 10;

            >li {
                display: block;
                color: #000;
                padding: 12px;
                font-size: 60px;
                margin: 0 10px;
                cursor: pointer;

                &:first-child {
                    margin: 10px;
                }

                &:last-child {
                    margin-bottom: 10px;
                }

                &:hover {
                    background-color: #465A93;
                    color: white;
                    border-radius: 6px;
                }
            }

            &::-webkit-scrollbar {
                width: 15px;
            }

            &::-webkit-scrollbar-track {
                background-color: #eee;
                border-radius: 6px;
            }

            &::-webkit-scrollbar-thumb {
                background-color: #465A93;
                border-radius: 15px;
            }

            &::-webkit-scrollbar-button {
                background-color: #f9f9f9;
            }
        }
    }

    nav li.has-child>div {
    position: absolute;
    z-index: 9999; /* 一个较高的数值，确保它位于其他元素上方 */
    border-radius: 5%;
    right: 0;
    top: 62px;
    background: white;
    width: 200px;
    visibility: hidden;
    opacity: 0;
    transition: all .3s;
}

.analysis{
    font-size:60px;
    background-color:#F0EEE2;
}

.label1{
    font-size:40px;
    width:50px;
}


</style>

<body>
<header id="header">
        <a href="speech_home.php" class="logo">
            <p class="speech_logo">Logo</p>
        </a>
        <nav>
            <ul>
                <li class="has-child"><img class="icon" src="three.jpg"> <!--class="in"-->
                    <div>
                        <ul>
                            <div class="pro_icon">
                                <img src="<?php echo $user_icon; ?>">
                                <div class="info">
                                    <p><?php echo $user_name; ?></p>
                                </div>
                            </div>
                            <li class="menu"><a href="ABOUT US.html">Profile</a></li>
                            <li class="menu"><a href="speech_home.php">Home</a></li>
                            <li class="menu"><a href="#">About</a></li>
                            <li class="menu"><a href="編輯畫面.html">Practice</a></li>
                            <li class="menu"><a href="record.php">Record</a></li>
                            <li class="menu"><a href="#">setting</a></li>
                            <li class="menu"><a href="speech_home_before_login.php">LOG OUT</a></li>
                            <br>
                        </ul>
                    </div>
                </li>
            </ul>
        </nav>
    </header>
    <!--<div class="wall"></div>-->
    <hr class="hr-1">
    <hr class="hr-2">
    <div class="container">
        <div class="middle-column">
            <div class="option-box"></div>
            <center><h1 class="analysis">Vocabulary score analysis</h1></center>
            <div class="container-option">

                <div style="width:20%; float:left;">
                    <label class="label1" for="questionSelect">Select :</label>
                    
                    <select id="questionSelect" onchange="updateChart();">
                        <option value="1">A</option>
                        <option value="2">B</option>
                        <option value="2">C</option>
                        <option value="2">D</option>
                        <option value="2">E</option>
                        <option value="2">F</option>
                    </select>
                     
                </div>
                <!-- 長條圖元素 -->
                <center><div style="width:900px;height: 800px;">
                    <canvas id="myChart" style="width:900px;height: 800px;margin-top: 200px;"></canvas>
                </div>
            
                <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-moment@1.0.1/dist/chartjs-adapter-moment.min.js"></script>
                <!-- 加入下面的script來定義和繪製長條圖 -->
                <script src="chartContent.js"></script></center>
            </div>
        </div>
    </div>
    <!--頁尾-->
    <footer>
        <p>@other information</p>
    </footer>
</body>

</html>
const questions = [
    {
        question: "Question1",
        options: ["選項0", "選項1", "選項2", "選項3"],
        correctAnswer: 1
    },
    {
        question: "Question2",
        options: ["選項0", "選項1", "選項2", "選項3"],
        correctAnswer: 2
    },
];

let currentQuestionIndex = 0;
let userScore = 0;

const questionText = document.querySelector('h2');
const questioncontent = document.querySelector('h3');
const optionsForm = document.querySelector('form');
const nextButton = document.querySelector('button');
const resultButton = document.querySelectorAll('button')[1];

function displayQuestion() {
    if (currentQuestionIndex < questions.length) {
        questionText.textContent = questions[currentQuestionIndex].question;
        questioncontent.textContent = "The politician was able to __________ her policy positions in a clear and concise manner. ";
        optionsForm.innerHTML = "";

        questions[currentQuestionIndex].options.forEach((option, index) => {
            const input = document.createElement('input');
            input.type = "radio";
            input.name = "answer";
            input.value = index;
            input.id = `option${index}`;
            const label = document.createElement('label');
            label.setAttribute('for', `option${index}`);
            label.textContent = option;

            optionsForm.appendChild(input);
            optionsForm.appendChild(label);
            optionsForm.appendChild(document.createElement('br'));
        });
    } else {

        showResult();
    }
}

function nextQuestion() {
    const selectedOption = document.querySelector('input[name="answer"]:checked');

    if (selectedOption) {
        const userAnswer = parseInt(selectedOption.value);

        if (userAnswer === questions[currentQuestionIndex].correctAnswer) {
            userScore++;
        }

        currentQuestionIndex++;

        if (currentQuestionIndex === questions.length) {
            nextButton.style.display = "none";
            resultButton.style.display = "block";
        }

        displayQuestion();
    }
}

function showResult() {
    const totalQuestions = questions.length;
    const percentage = (userScore / totalQuestions) * 100;

    questionText.textContent = "您的得分";
    optionsForm.innerHTML = `您的分數：${userScore} / ${totalQuestions}<br>百分比：${percentage}%`;
    resultButton.style.display = "none";
    h3.style.display = "none";
}

displayQuestion();
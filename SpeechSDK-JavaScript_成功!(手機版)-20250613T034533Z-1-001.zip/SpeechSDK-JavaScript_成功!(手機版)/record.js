var resultDiv = document.getElementById('result');//顯示提示訊息，可刪除
var mediaRecorder;
var recordedChunks = [];
var isRecording = false;
var stream;

function toggleRecording() {
    isRecording = !isRecording;
    var recordButton = document.getElementById('recordButton');

    if (isRecording) {
        startRecording();
        recordButton.classList.add('active'); // 添加 active 類別，使按鈕變色並開始閃爍
    } else {
        stopRecording();
        recordButton.classList.remove('active'); // 移除 active 類別，停止閃爍
    }
}

async function startRecording() {
    try {
        recordedChunks = []; // 重置錄音數據陣列
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);

        mediaRecorder.ondataavailable = function (event) {
            if (event.data.size > 0) {
                recordedChunks.push(event.data);
            }
        };

        mediaRecorder.onstop = function () {
            isRecording = false;
            saveRecording();
        };

        mediaRecorder.start();
        isRecording = true;
    } catch (error) {
        resultDiv.textContent = '無法獲取麥克風訪問權限: ' + error.message;
    }
}

function stopRecording() {
    mediaRecorder.stop();
    stream.getTracks().forEach(track => track.stop());
}

function saveRecording() {
    var blob = new Blob(recordedChunks, { type: 'audio/ogg' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'recorded_data.ogg';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);

    resultDiv.textContent = "錄音已儲存";
}
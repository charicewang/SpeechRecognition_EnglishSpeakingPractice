const questions = [
    {
        question: "Question1",
        options: ["abandon", "authenticity", "abiding", "ability"],
        correctAnswer: 1
    },
    {
        question: "Question2",
        options: ["ablaze", "abbreviate", "articulate", "abstain"],
        correctAnswer: 2
    },
    {
        question: "Question3",
        options: ["absorb", "abstain", "advocate", "abstract"],
        correctAnswer: 2
    },
    {
        question: "Question4",
        options: ["absurd", "abundant", "abyss", "asserted"],
        correctAnswer: 3
    },
    {
        question: "Question5",
        options: ["abate", "aberrant", "abode", "Artificial intelligence"],
        correctAnswer: 3
    },

];

let currentQuestionIndex = 0;
let userScore = 0;
let currentQuestioncontent_num = 0;
let currentQuestioncontent = ["The author takes great care to maintain the _________ of the time period, incorporating accurate historical details and language.",
    "The politician was able to _________ her policy positions in a clear and concise manner.",
    "She _________ for stronger environmental regulations to protect the planet.",
    "He _________ that his theory was backed by substantial evidence.",
    "The company is investing heavily in _________ to improve their customer service. "];

const questionText = document.querySelector('h2');
const questioncontent = document.querySelector('h3');
const optionsForm = document.querySelector('form');
const nextButton = document.querySelector('button');
const resultButton = document.querySelectorAll('button')[1];
const score = document.getElementById('scoreinfo');

function displayQuestion() {
    if (currentQuestionIndex < questions.length) {
        questionText.textContent = questions[currentQuestionIndex].question;
        questioncontent.textContent = currentQuestioncontent[currentQuestioncontent_num];
        optionsForm.innerHTML = "";

        questions[currentQuestionIndex].options.forEach((option, index) => {
            const input = document.createElement('input');
            input.type = "radio";
            input.name = "answer";
            input.value = index;
            input.id = `option${index}`;
            const label = document.createElement('label');
            label.setAttribute('for', `option${index}`);
            label.textContent = option;

            optionsForm.appendChild(input);
            optionsForm.appendChild(label);
            optionsForm.appendChild(document.createElement('br'));
        });
    } else {

        showResult();
    }
}

function nextQuestion() {
    const selectedOption = document.querySelector('input[name="answer"]:checked');

    if (selectedOption) {
        const userAnswer = parseInt(selectedOption.value);

        if (userAnswer === questions[currentQuestionIndex].correctAnswer) {
            userScore++;
        }

        currentQuestionIndex++;
        currentQuestioncontent_num++;

        if (currentQuestionIndex === questions.length) {
            nextButton.style.display = "none";
            resultButton.style.display = "block";
        }

        displayQuestion();
    }
}

function showResult() {
    const totalQuestions = questions.length;
    const percentage = (userScore / totalQuestions) * 100;

    //questionText.textContent = "Your score:";
    //score.innerHTML = `您的分數：${userScore} / ${totalQuestions}<br>百分比：${percentage}%`;
    score.innerHTML = `<div class="info">
    <!--左側區塊-->
    <div>
        <div class="score-image-container">
            <span id="iscorrect"></span>
        </div>
    </div>
    <div>
        <div class="score-image-container">
            <span id="scorepercen"></span>
        </div>
    </div>    
</div>
<hr>
<p class="notice">Your Answer:</p>
    <div class = "allcontent"><div class = "answer-content">
        <div class = "youranswer">
            1. The author takes great care to maintain the <span class="red">abiding</span> of the time period, incorporating accurate historical details and language.
        </div>
        <div class = "correctanswer">
            Correct answer: <span class = "blue">authenticity</span>
        </div>
    </div>

    <div class = "answer-content">
        <div class = "youranswer">
            2. The politician was able to <span class="blue">articulate</span> her policy positions in a clear and concise manner.
        </div>
        <div class = "correctanswer">
            Correct answer: <span class = "blue">articulate</span>
        </div>
    </div>

    <div class = "answer-content">
        <div class = "youranswer">
            3. She <span class="blue">advocate</span> for stronger environmental regulations to protect the planet.
        </div>
        <div class = "correctanswer">
            Correct answer: <span class = "blue">advocate</span>
        </div>
    </div>

    <div class = "answer-content">
        <div class = "youranswer">
            4. He <span class="blue">asserted</span> that his theory was backed by substantial evidence.
        </div>
        <div class = "correctanswer">
            Correct answer: <span class = "blue">asserted</span>
        </div>
    </div>

    <div class = "answer-content">
        <div class = "youranswer">
            5. The company is investing heavily in <span class="blue">Artificial intelligence</span> to improve their customer service.
        </div>
        <div class = "correctanswer">
            Correct answer: <span class = "blue">Artificial intelligence</span>
        </div>
    </div></div>
    
    <div class="chat-box-score">
        <div class="chat-container">
            <div id="content">
            </div>
            <div id="ha"></div>
        </div>
    </div>
    <a href="Vocabularyoption.php"><button id="again_button">Try again!</button></a>
</div>`;
    const iscorrect = document.getElementById('iscorrect');
    score.className = "score-info";
    iscorrect.textContent = userScore + "/" + totalQuestions;
    const scorepercen = document.getElementById('scorepercen');
    scorepercen.textContent = percentage + "%";
    resultButton.style.display = "none";
    questioncontent.style.display = "none";
    optionsForm.style.display = "none";
    questionText.style.display = "none";
}

displayQuestion();